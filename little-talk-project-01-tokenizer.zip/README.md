# Little Talk AI - Project 1: Character-Level Tokenizer

A small tokenizer written from scratch in plain Python. It is the first building
block of Little Talk AI, a language model that will eventually be trained from
random initial weights. This project contains **only** the tokenizer.

- No pretrained models, no external AI APIs, no downloads.
- Standard library only (Python 3.8 or newer). Runs on any ordinary computer.

## Files

| File | Purpose |
|------|---------|
| `tokenizer.py` | The `CharTokenizer` class |
| `test_tokenizer.py` | Unit tests (24 tests, `unittest`) |
| `data/sample.txt` | Small sample corpus (about 1.3 KB) |
| `requirements.txt` | Says no third-party packages are needed |

## Run the tests

From inside the project folder:

```
python -m unittest -v
```

(On some systems use `python3` instead of `python`.) A passing run ends with `OK`.

## Run the demo

```
python tokenizer.py data/sample.txt
```

## Use it in code

```python
from tokenizer import CharTokenizer

tok = CharTokenizer.train_from_file("data/sample.txt")   # build vocabulary
ids = tok.encode("Hello!", add_bos=True, add_eos=True)    # text -> IDs
text = tok.decode(ids)                                    # IDs -> text
tok.save("vocab.json")                                    # save vocabulary
tok2 = CharTokenizer.load("vocab.json")                   # load it again
```

## How it works

- **Vocabulary:** every distinct character in the corpus, sorted, so the same
  corpus always gives the same IDs. `train(text, min_freq=1)` can also drop
  characters that appear fewer than `min_freq` times.
- **Special tokens** (always IDs 0-3): `<pad>`, `<unk>`, `<bos>`, `<eos>`.
- **Unknown characters:** `encode` maps any character not in the vocabulary to
  `<unk>`. It never raises an error and the output length always equals the
  input length (plus optional `<bos>`/`<eos>`). `decode` shows `<unk>` as the
  replacement character `\ufffd`, so the original character is lost, which is
  expected.
- **Decode:** by default skips `<pad>`, `<bos>`, `<eos>`. Use
  `skip_special=False` to see them. An invalid ID raises `ValueError`.
- **Save/load:** UTF-8 JSON with a format version. `load` validates the file and
  raises `ValueError` for anything malformed.

## Limitations of character-level tokenization

1. **Long sequences.** One token per character means a sentence is 5-6 times
   longer than with word or subword tokens. Training and generation cost grows
   quickly with sequence length (attention is roughly quadratic), which hurts on
   limited hardware.
2. **Short effective memory.** A model with a fixed context window of, say,
   256 tokens sees only 256 characters, about two short sentences.
3. **Harder learning.** The model must learn spelling and word boundaries before
   it can learn meaning, and tokens carry little meaning on their own.
4. **Unknown characters are lost.** Anything outside the training corpus
   (emoji, other scripts, rare accents) becomes `<unk>` and cannot be recovered.
   A small sample corpus means a small vocabulary and many unknowns.
5. **Unicode subtleties.** The tokenizer works on Python code points, not
   user-perceived characters. An accented letter may be one code point
   (`\u00e9`) or two (`e` + combining accent), and these get different IDs.
   Emoji with modifiers span several code points. No Unicode normalization is
   applied. Normalizing the corpus first (for example NFC) is a sensible later step.
6. **Vocabulary depends on the corpus.** Different corpora give different
   IDs, so always save the vocabulary with the model that was trained with it.
7. **No learned merges.** Subword methods such as byte-pair encoding (BPE) trade
   a larger vocabulary for shorter sequences and are the usual choice for larger
   models. Character-level is a good, simple starting point and fine for tiny
   models and experiments.

## Scope

This is Project 1 only. Training data pipelines, model code and chat features
are intentionally not included.
