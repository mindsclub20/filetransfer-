"""Little Talk AI - Project 1: a small character-level tokenizer.

Pure Python standard library. No pretrained models, no downloads.

Every distinct character seen in the training corpus gets an integer ID.
Four special tokens always occupy the first IDs:

    0 <pad>   padding (used later to make batches the same length)
    1 <unk>   any character that was not in the corpus
    2 <bos>   beginning of a sequence
    3 <eos>   end of a sequence
"""

import json
import sys
from collections import Counter

PAD, UNK, BOS, EOS = "<pad>", "<unk>", "<bos>", "<eos>"
SPECIAL_TOKENS = [PAD, UNK, BOS, EOS]
FORMAT_VERSION = 1
UNK_REPLACEMENT = "\ufffd"  # shown when decoding an <unk> id


class CharTokenizer:
    """Maps single characters to integer IDs and back."""

    def __init__(self, chars=()):
        chars = list(chars)
        for ch in chars:
            if not isinstance(ch, str) or len(ch) != 1:
                raise ValueError(f"Vocabulary entries must be single characters, got {ch!r}")
        if len(set(chars)) != len(chars):
            raise ValueError("Vocabulary contains duplicate characters")

        self.id_to_token = SPECIAL_TOKENS + chars
        self.token_to_id = {tok: i for i, tok in enumerate(self.id_to_token)}
        self.pad_id = self.token_to_id[PAD]
        self.unk_id = self.token_to_id[UNK]
        self.bos_id = self.token_to_id[BOS]
        self.eos_id = self.token_to_id[EOS]

    # ---- building -------------------------------------------------------
    @classmethod
    def train(cls, text, min_freq=1):
        """Build a vocabulary from `text`.

        Characters seen fewer than `min_freq` times are left out, so they
        will be encoded as <unk>. Characters are sorted, so the same corpus
        always produces the same IDs.
        """
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        if min_freq < 1:
            raise ValueError("min_freq must be at least 1")
        counts = Counter(text)
        chars = sorted(ch for ch, n in counts.items() if n >= min_freq)
        return cls(chars)

    @classmethod
    def train_from_file(cls, path, min_freq=1):
        with open(path, "r", encoding="utf-8") as f:
            return cls.train(f.read(), min_freq=min_freq)

    # ---- properties -----------------------------------------------------
    @property
    def vocab_size(self):
        return len(self.id_to_token)

    def __len__(self):
        return self.vocab_size

    # ---- encode / decode ------------------------------------------------
    def encode(self, text, add_bos=False, add_eos=False):
        """Turn text into a list of integer IDs. Unknown characters -> <unk>."""
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        ids = [self.token_to_id.get(ch, self.unk_id) for ch in text]
        if add_bos:
            ids.insert(0, self.bos_id)
        if add_eos:
            ids.append(self.eos_id)
        return ids

    def decode(self, ids, skip_special=True):
        """Turn IDs back into text.

        skip_special=True  : <pad>, <bos>, <eos> are dropped; <unk> becomes
                             the replacement character U+FFFD.
        skip_special=False : all special tokens appear as their literal tags.
        Raises ValueError for an ID that is not in the vocabulary.
        """
        parts = []
        for i in ids:
            if isinstance(i, bool) or not isinstance(i, int):
                raise ValueError(f"Token IDs must be integers, got {i!r}")
            if i < 0 or i >= self.vocab_size:
                raise ValueError(f"Token ID {i} is out of range (vocab size {self.vocab_size})")
            tok = self.id_to_token[i]
            if tok in SPECIAL_TOKENS:
                if not skip_special:
                    parts.append(tok)
                elif tok == UNK:
                    parts.append(UNK_REPLACEMENT)
            else:
                parts.append(tok)
        return "".join(parts)

    # ---- saving / loading -----------------------------------------------
    def save(self, path):
        """Save the vocabulary as UTF-8 JSON."""
        data = {
            "format_version": FORMAT_VERSION,
            "type": "char",
            "tokens": self.id_to_token,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path):
        """Load a vocabulary saved by `save`. Raises ValueError if invalid."""
        with open(path, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                raise ValueError(f"Not a valid tokenizer file: {e}") from e
        if not isinstance(data, dict) or data.get("type") != "char":
            raise ValueError("Not a character tokenizer file")
        if data.get("format_version") != FORMAT_VERSION:
            raise ValueError(f"Unsupported format_version: {data.get('format_version')!r}")
        tokens = data.get("tokens")
        if not isinstance(tokens, list) or tokens[: len(SPECIAL_TOKENS)] != SPECIAL_TOKENS:
            raise ValueError("Token list must start with the special tokens")
        return cls(tokens[len(SPECIAL_TOKENS):])


def main(argv):
    """Tiny demo: python tokenizer.py data/sample.txt"""
    path = argv[1] if len(argv) > 1 else "data/sample.txt"
    tok = CharTokenizer.train_from_file(path)
    print(f"Vocabulary size: {tok.vocab_size} (including {len(SPECIAL_TOKENS)} special tokens)")
    sample = "Hello, little talk!"
    ids = tok.encode(sample)
    print(f"Text:    {sample!r}")
    print(f"IDs:     {ids}")
    print(f"Decoded: {tok.decode(ids)!r}")
    print(f"Unknown-character demo: {tok.encode('a\u2603b')} -> {tok.decode(tok.encode('a\u2603b'))!r}")


if __name__ == "__main__":
    main(sys.argv)
