"""Unit tests for tokenizer.py. Run with:  python -m unittest -v"""

import json
import os
import tempfile
import unittest

from tokenizer import (BOS, EOS, PAD, SPECIAL_TOKENS, UNK, UNK_REPLACEMENT,
                       CharTokenizer)

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLE = os.path.join(HERE, "data", "sample.txt")


class TestVocabulary(unittest.TestCase):
    def test_special_tokens_come_first(self):
        tok = CharTokenizer.train("ab")
        self.assertEqual(tok.id_to_token[:4], [PAD, UNK, BOS, EOS])
        self.assertEqual((tok.pad_id, tok.unk_id, tok.bos_id, tok.eos_id), (0, 1, 2, 3))

    def test_vocab_is_sorted_and_deduplicated(self):
        tok = CharTokenizer.train("banana")
        self.assertEqual(tok.id_to_token[4:], ["a", "b", "n"])
        self.assertEqual(tok.vocab_size, 7)
        self.assertEqual(len(tok), 7)

    def test_training_is_deterministic(self):
        a = CharTokenizer.train("hello world")
        b = CharTokenizer.train("hello world")
        self.assertEqual(a.id_to_token, b.id_to_token)

    def test_empty_corpus_gives_only_special_tokens(self):
        tok = CharTokenizer.train("")
        self.assertEqual(tok.vocab_size, len(SPECIAL_TOKENS))

    def test_min_freq_drops_rare_characters(self):
        tok = CharTokenizer.train("aaabbc", min_freq=2)
        self.assertIn("a", tok.token_to_id)
        self.assertIn("b", tok.token_to_id)
        self.assertNotIn("c", tok.token_to_id)
        self.assertEqual(tok.encode("c"), [tok.unk_id])

    def test_bad_arguments(self):
        with self.assertRaises(TypeError):
            CharTokenizer.train(123)
        with self.assertRaises(ValueError):
            CharTokenizer.train("abc", min_freq=0)
        with self.assertRaises(ValueError):
            CharTokenizer(["ab"])          # not a single character
        with self.assertRaises(ValueError):
            CharTokenizer(["a", "a"])      # duplicate


class TestEncodeDecode(unittest.TestCase):
    def setUp(self):
        self.tok = CharTokenizer.train("hello world")

    def test_round_trip(self):
        ids = self.tok.encode("hello world")
        self.assertTrue(all(isinstance(i, int) for i in ids))
        self.assertEqual(self.tok.decode(ids), "hello world")

    def test_encode_empty_string(self):
        self.assertEqual(self.tok.encode(""), [])
        self.assertEqual(self.tok.decode([]), "")

    def test_same_character_same_id(self):
        ids = self.tok.encode("lol")
        self.assertEqual(ids[0], ids[2])

    def test_unknown_characters_become_unk(self):
        ids = self.tok.encode("hi!")      # 'i' and '!' are not in the corpus
        self.assertEqual(ids[1], self.tok.unk_id)
        self.assertEqual(ids[2], self.tok.unk_id)
        self.assertEqual(len(ids), 3)     # length is preserved

    def test_unknown_characters_never_crash(self):
        text = "caf\u00e9 \u2603 \U0001F600 \u4e2d\u6587 \x00"
        ids = self.tok.encode(text)
        self.assertEqual(len(ids), len(text))
        self.tok.decode(ids)              # must not raise

    def test_decode_shows_replacement_for_unk(self):
        ids = self.tok.encode("h\u2603h")
        self.assertEqual(self.tok.decode(ids), "h" + UNK_REPLACEMENT + "h")

    def test_bos_and_eos(self):
        ids = self.tok.encode("hi", add_bos=True, add_eos=True)
        self.assertEqual(ids[0], self.tok.bos_id)
        self.assertEqual(ids[-1], self.tok.eos_id)
        self.assertEqual(self.tok.decode(ids), "h" + UNK_REPLACEMENT)
        self.assertEqual(self.tok.decode(ids, skip_special=False), "<bos>h<unk><eos>")

    def test_decode_skips_padding(self):
        ids = self.tok.encode("hello") + [self.tok.pad_id] * 3
        self.assertEqual(self.tok.decode(ids), "hello")

    def test_decode_rejects_bad_ids(self):
        for bad in ([-1], [self.tok.vocab_size], ["a"], [1.5], [True]):
            with self.assertRaises(ValueError):
                self.tok.decode(bad)

    def test_encode_rejects_non_string(self):
        with self.assertRaises(TypeError):
            self.tok.encode(["h", "i"])

    def test_whitespace_and_newlines_preserved(self):
        tok = CharTokenizer.train("a b\nc\td")
        text = "a b\nc\td"
        self.assertEqual(tok.decode(tok.encode(text)), text)


class TestSaveLoad(unittest.TestCase):
    def test_save_and_load_gives_identical_tokenizer(self):
        tok = CharTokenizer.train("Hello, caf\u00e9! \u2603")
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "vocab.json")
            tok.save(path)
            loaded = CharTokenizer.load(path)
        self.assertEqual(tok.id_to_token, loaded.id_to_token)
        text = "Hello, caf\u00e9! \u2603 zzz"
        self.assertEqual(tok.encode(text), loaded.encode(text))

    def test_saved_file_is_readable_utf8_json(self):
        tok = CharTokenizer.train("a\u00e9")
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "vocab.json")
            tok.save(path)
            with open(path, encoding="utf-8") as f:
                raw = f.read()
        self.assertIn("\u00e9", raw)      # not escaped away
        data = json.loads(raw)
        self.assertEqual(data["tokens"][:4], SPECIAL_TOKENS)

    def test_load_rejects_bad_files(self):
        bad_payloads = [
            "not json at all",
            json.dumps([1, 2, 3]),
            json.dumps({"type": "word", "format_version": 1, "tokens": SPECIAL_TOKENS}),
            json.dumps({"type": "char", "format_version": 99, "tokens": SPECIAL_TOKENS}),
            json.dumps({"type": "char", "format_version": 1, "tokens": ["a", "b"]}),
            json.dumps({"type": "char", "format_version": 1, "tokens": SPECIAL_TOKENS + ["ab"]}),
            json.dumps({"type": "char", "format_version": 1, "tokens": SPECIAL_TOKENS + ["a", "a"]}),
        ]
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "bad.json")
            for payload in bad_payloads:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(payload)
                with self.assertRaises(ValueError, msg=payload):
                    CharTokenizer.load(path)

    def test_load_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            CharTokenizer.load(os.path.join(tempfile.gettempdir(), "no_such_vocab_file.json"))


class TestSampleCorpus(unittest.TestCase):
    def test_sample_file_exists_and_is_small(self):
        self.assertTrue(os.path.isfile(SAMPLE))
        self.assertLess(os.path.getsize(SAMPLE), 10_000)

    def test_train_on_sample_and_round_trip_itself(self):
        tok = CharTokenizer.train_from_file(SAMPLE)
        with open(SAMPLE, encoding="utf-8") as f:
            text = f.read()
        ids = tok.encode(text)
        self.assertNotIn(tok.unk_id, ids)  # every training char is known
        self.assertEqual(tok.decode(ids), text)

    def test_sample_covers_basics(self):
        tok = CharTokenizer.train_from_file(SAMPLE)
        for ch in "abcxyzABCXYZ0123456789 .,!?\n":
            self.assertIn(ch, tok.token_to_id)


if __name__ == "__main__":
    unittest.main()
