"""Generate text from a saved checkpoint.

    python generate.py --checkpoint checkpoints/bigram.npz --start T --length 300 --seed 1
"""

import argparse
import sys

from bigram_model import generate_text, load_checkpoint


def main(argv=None):
    p = argparse.ArgumentParser(description="Generate text with a trained bigram model.")
    p.add_argument("--checkpoint", default="checkpoints/bigram.npz")
    p.add_argument("--start", required=True, help="one starting character")
    p.add_argument("--length", type=int, default=300)
    p.add_argument("--temperature", type=float, default=1.0)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args(argv)
    try:
        model, tok, _ = load_checkpoint(args.checkpoint)
        print(generate_text(model, tok, args.start, args.length, args.temperature, args.seed))
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
