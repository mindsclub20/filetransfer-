# Little Talk AI - Project 2: Character-Level Bigram Model

A tiny language model built from scratch. It learns which characters tend to
follow which other characters, trains on a local text file, reports training
and validation loss, saves/loads checkpoints, and generates text from a
starting character you choose.

- Weights start as random numbers (seeded). No pretrained weights, no external AI APIs, no downloads.
- Uses the Project 1 tokenizer (`tokenizer.py`, included unchanged).
- Needs Python 3.8+ and NumPy only. Trains in seconds on an ordinary CPU, using a few MB of RAM.
- This is Project 2 only. There is no neural network with hidden layers, no attention, and no chat.

## Files

| File | Purpose |
|------|---------|
| `tokenizer.py` | Project 1 character tokenizer (unchanged) |
| `bigram_model.py` | The model, loss and hand-derived gradient, generation, checkpoints |
| `train.py` | Training loop and command-line trainer |
| `generate.py` | Generate text from a saved checkpoint |
| `test_bigram.py`, `test_tokenizer.py` | Unit tests (53 in total) |
| `data/corpus.txt` | Training corpus, 113,899 characters (synthetic, see Limitations) |
| `data/make_corpus.py` | Recreates `corpus.txt` exactly (fixed seed) |
| `data/sample.txt` | Small corpus from Project 1 (used by the tokenizer tests) |
| `checkpoints/bigram.npz` | Checkpoint from the logged run |
| `training_log.txt` | Log of that run |

## Setup

```
pip install -r requirements.txt
```

## Run the tests

```
python -m unittest -v
```

A passing run ends with `Ran 53 tests ... OK`.

## Train

```
python train.py --corpus data/corpus.txt --steps 2000 --seed 42 --log-file training_log.txt
```

Useful options: `--lr` (default 20), `--batch-size` (4096), `--val-fraction` (0.1),
`--eval-every` (100), `--out` (checkpoint path), `--samples`, `--sample-length`.
To train on your own text, pass any local UTF-8 file with `--corpus`.

## Generate

```
python generate.py --checkpoint checkpoints/bigram.npz --start T --length 300 --seed 1
```

`--start` must be exactly one character that appeared in the training part of
the corpus; otherwise the script prints an error and exits with status 1.
`--temperature` below 1 is more cautious, above 1 is more random. The same
checkpoint, start, length, temperature and seed give the same text.

## How it works

The model is one table `W` of shape (vocab, vocab). Row `i` holds raw scores for
the character that follows character `i`:

    P(next = j | current = i) = softmax(W[i])[j]

- **Initialisation:** `W` starts as random normal numbers with standard deviation 0.02, so the model begins nearly uniform (loss close to ln(V)).
- **Loss:** average cross-entropy in nats per character. Perplexity = exp(loss).
- **Gradient:** for each (current, next) pair, the gradient on row `current` is `softmax(W[current]) - onehot(next)`, averaged over the batch. A unit test compares it to a numerical gradient.
- **Training:** mini-batch gradient descent on random batches of pairs.
- **Seeds:** one seed controls three separate random streams (initial weights, batch sampling, text generation), so they never interfere.
- **Validation:** the last 10% of the corpus is held out (contiguous). The vocabulary is built from the training part only, so a character that first appears in validation would count as `<unk>` (this corpus has none).
- **Generation:** repeatedly sample the next character from `softmax(W[current] / temperature)`. Special tokens are never sampled.
- **Checkpoints:** one `.npz` file with weights, vocabulary and settings. It is loaded with `allow_pickle=False`, and the loader validates shape, vocabulary and finiteness.

## Measured results

From `training_log.txt` (seed 42, 2,000 steps, batch 4,096, lr 20, vocabulary 59, 3,481 parameters). Training took 7.1 s on the CPU in this environment.

| Model | Validation loss (nats/char) | Perplexity |
|-------|------------------|-----------|
| Random initial weights (step 0) | 4.0788 | 59.07 |
| Uniform guessing, ln(59) | 4.0775 | 59 |
| Letter-frequency only (add-1 smoothed, no context) | 3.1042 | about 22.3 |
| Count-based bigram, add-1 smoothing (reference) | 2.0879 | about 8.1 |
| **Trained bigram model, step 2000** | **2.0714** | **7.94** |

Train loss at step 2000 was 2.0726. Loss was still falling very slowly at the
end (2.0736 to 2.0726 over the last 250 steps), so it is close to converged.
The gradient-descent result is slightly better than the add-1 count reference
because add-1 smoothing is a fairly heavy prior; the reference is a sanity
check, not a lower bound.

Running the same command twice with the same seed gave bit-identical weights on
this machine. Other machines or NumPy versions may differ in the last decimal places.

Unit-test results: 53 tests, all passing (24 tokenizer, 29 bigram/training).

## Limitations

1. **It only sees one character.** The next-character guess depends on nothing else, so the output looks like word-shaped noise (see the samples in the log). It never forms real sentences or meaning, however long you train. This is the expected ceiling of a bigram model, not a bug.
2. **Train and validation loss almost match (2.0726 vs 2.0714)**, because the corpus is synthetic and built from templates, so the held-out tail looks just like the training part. Validation here shows the code works. It is not strong evidence of how the model would do on varied real-world text. The 3,481 parameters can hardly overfit either.
3. **The corpus is synthetic and small.** `corpus.txt` is generated from templates, which makes it more predictable than real writing. Loss numbers on real text would be higher and not comparable to these.
4. **Fixed learning rate, plain SGD.** No scheduling and no early stopping. The default `lr=20` suits this vocabulary size and mean-averaged loss. It may need retuning for very different corpora.
5. **Characters only.** Inherits the Project 1 tokenizer limits: unknown characters become `<unk>`, there is no Unicode normalization, and sequences are long compared with word or subword tokens.
6. **The count-based reference is just a reference.** It uses add-1 smoothing, so a lower loss than it does not mean the model is better in any deeper sense.
7. **Memory scales with vocabulary squared.** Fine for characters (59 x 59 here), but a table like this would be impractical for a large word-level vocabulary. That is one reason later projects will use a learned embedding and a deeper network.
