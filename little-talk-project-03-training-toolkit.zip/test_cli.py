"""End-to-end tests for run_training.py and generate.py (the command-line scripts)."""

import contextlib
import io
import os
import tempfile
import unittest

import generate
import run_training

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "data", "corpus.txt")


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def run(main, argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = main(argv)
    return code, out.getvalue(), err.getvalue()


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.dir = self._td.name
        self.addCleanup(self._td.cleanup)
        self.out = os.path.join(self.dir, "run")

    def train(self, *extra, data=CORPUS):
        argv = ["--data", data, "--out-dir", self.out, "--batch-size", "512",
                "--eval-every", "25", "--checkpoint-every", "50", "--seed", "3"] + list(extra)
        return run(run_training.main, argv)

    def write(self, name, text):
        path = os.path.join(self.dir, name)
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        return path


class TestTrainCli(Base):
    def test_trains_and_writes_everything(self):
        code, out, err = self.train("--steps", "50")
        self.assertEqual(code, 0, err)
        for name in ("train.log", "metrics.csv", "config.json"):
            self.assertTrue(os.path.isfile(os.path.join(self.out, name)), name)
        ck = os.listdir(os.path.join(self.out, "checkpoints"))
        self.assertIn("best.npz", ck)
        self.assertIn("step_0000050.npz", ck)
        self.assertIn("finished at step 50", out)

    def test_missing_data_file(self):
        code, _, err = self.train("--steps", "10", data=os.path.join(self.dir, "none.txt"))
        self.assertEqual(code, 2)
        self.assertIn("does not exist", err)

    def test_empty_and_whitespace_data(self):
        for text in ("", "   \n\n  "):
            code, _, err = self.train("--steps", "10", data=self.write("e.txt", text))
            self.assertEqual(code, 2)
            self.assertIn("empty", err)
        self.assertFalse(os.path.exists(os.path.join(self.out, "checkpoints")))

    def test_too_short_data(self):
        code, _, err = self.train("--steps", "10", data=self.write("s.txt", "tiny"))
        self.assertEqual(code, 2)
        self.assertIn("at least", err)

    def test_bad_settings(self):
        for flag, val in (("--steps", "0"), ("--lr", "0"), ("--val-fraction", "1.5")):
            code, _, err = self.train(flag, val)
            self.assertEqual(code, 2, flag)
            self.assertIn("Error:", err)

    def test_refuses_to_overwrite_then_resume_extends(self):
        self.assertEqual(self.train("--steps", "50")[0], 0)
        logs = {n: read(os.path.join(self.out, n)) for n in ("train.log", "metrics.csv", "config.json")}
        code, out, err = self.train("--steps", "100")
        self.assertEqual(code, 2)
        self.assertIn("resume", err.lower())
        self.assertEqual(out, "")                       # refused before printing/logging anything
        for n, before in logs.items():                  # earlier run's files are untouched
            self.assertEqual(read(os.path.join(self.out, n)), before, n)
        code, out, err = self.train("--steps", "100", "--resume")
        self.assertEqual(code, 0, err)
        self.assertIn("Resuming from step 50", out)
        self.assertIn("finished at step 100", out)

    def test_data_folder_is_accepted(self):
        folder = os.path.join(self.dir, "texts")
        os.makedirs(folder)
        with open(CORPUS, encoding="utf-8") as f:
            text = f.read()
        for i in range(2):
            with open(os.path.join(folder, f"part{i}.txt"), "w", encoding="utf-8") as g:
                g.write(text[i * 5000:(i + 1) * 5000])
        code, out, err = self.train("--steps", "25", data=folder)
        self.assertEqual(code, 0, err)


class TestGenerateCli(Base):
    def setUp(self):
        super().setUp()
        self.assertEqual(self.train("--steps", "50")[0], 0)

    def test_generates_from_run_folder(self):
        code, out, err = run(generate.main, ["--checkpoint", self.out, "--start", "T", "--length", "80", "--seed", "1"])
        self.assertEqual(code, 0, err)
        self.assertEqual(len(out.rstrip("\n")), 81)
        self.assertEqual(out[0], "T")

    def test_same_seed_same_text_and_best_option(self):
        args = ["--checkpoint", self.out, "--start", "M", "--length", "60", "--seed", "4"]
        self.assertEqual(run(generate.main, args)[1], run(generate.main, args)[1])
        code, out, _ = run(generate.main, args + ["--best"])
        self.assertEqual(code, 0)
        self.assertEqual(out[0], "M")

    def test_generates_from_checkpoint_file_and_multiple_samples(self):
        path = os.path.join(self.out, "checkpoints", "best.npz")
        code, out, _ = run(generate.main, ["--checkpoint", path, "--start", "T", "--length", "20", "--count", "2"])
        self.assertEqual(code, 0)
        self.assertIn("--- sample 2 (seed 1) ---", out)

    def test_bad_inputs_give_clean_errors(self):
        for argv in (["--checkpoint", self.out, "--start", "\u2603"],
                     ["--checkpoint", self.out, "--start", "ab"],
                     ["--checkpoint", self.out, "--start", "T", "--temperature", "0"],
                     ["--checkpoint", os.path.join(self.dir, "missing"), "--start", "T"],
                     ["--checkpoint", self.dir, "--start", "T"]):
            code, out, err = run(generate.main, argv)
            self.assertEqual(code, 1, argv)
            self.assertIn("Error:", err)
            self.assertEqual(out, "")


if __name__ == "__main__":
    unittest.main()
