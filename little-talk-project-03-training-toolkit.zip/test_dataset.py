"""Tests for dataset.py (reading, validating, splitting). Run: python -m unittest -v"""

import os
import tempfile
import unittest

import numpy as np

from dataset import (DatasetError, load_dataset, load_text, prepare_dataset,
                     validate_text)

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "data", "corpus.txt")
GOOD = "The quick brown fox jumps over the lazy dog. " * 10   # 450 chars


class TempDirCase(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.dir = self._td.name
        self.addCleanup(self._td.cleanup)

    def write(self, name, data, mode="w"):
        path = os.path.join(self.dir, name)
        kwargs = {} if "b" in mode else {"encoding": "utf-8", "newline": ""}
        with open(path, mode, **kwargs) as f:
            f.write(data)
        return path


class TestLoadText(TempDirCase):
    def test_reads_a_file(self):
        self.assertEqual(load_text(self.write("a.txt", "hello\n")), "hello\n")

    def test_normalises_line_endings_and_bom(self):
        path = self.write("w.txt", b"\xef\xbb\xbfone\r\ntwo\rthree\n", "wb")
        self.assertEqual(load_text(path), "one\ntwo\nthree\n")

    def test_reads_unicode(self):
        self.assertEqual(load_text(self.write("u.txt", "caf\u00e9 \u2603")), "caf\u00e9 \u2603")

    def test_folder_of_txt_files_sorted_and_others_ignored(self):
        self.write("b.txt", "BBB")
        self.write("a.txt", "AAA")
        self.write("notes.md", "IGNORED")
        self.assertEqual(load_text(self.dir), "AAA\nBBB")

    def test_empty_folder(self):
        with self.assertRaises(DatasetError):
            load_text(self.dir)

    def test_missing_path(self):
        with self.assertRaises(DatasetError):
            load_text(os.path.join(self.dir, "nope.txt"))

    def test_binary_file_rejected(self):
        with self.assertRaises(DatasetError):
            load_text(self.write("b.bin", b"abc\x00def", "wb"))

    def test_invalid_utf8_rejected(self):
        with self.assertRaises(DatasetError):
            load_text(self.write("bad.txt", b"caf\xe9 is latin-1", "wb"))

    def test_size_limit(self):
        path = self.write("big.txt", "x" * 1000)
        with self.assertRaises(DatasetError):
            load_text(path, max_bytes=500)
        self.assertEqual(len(load_text(path, max_bytes=1000)), 1000)


class TestValidate(unittest.TestCase):
    def test_good_text_passes(self):
        validate_text(GOOD)

    def test_bad_text_rejected(self):
        for bad in ("", "   \n\t  ", "short text", "a" * 500, None, 123):
            with self.assertRaises(DatasetError, msg=repr(bad)):
                validate_text(bad)

    def test_min_chars_is_configurable(self):
        validate_text("hello there", min_chars=5)
        with self.assertRaises(DatasetError):
            validate_text("hello there", min_chars=50)


class TestPrepare(unittest.TestCase):
    def test_split_sizes_and_shapes(self):
        ds = prepare_dataset(GOOD, val_fraction=0.2)
        self.assertEqual(ds.n_chars, len(GOOD))
        self.assertEqual(len(ds.train_x), len(ds.train_y))
        self.assertEqual(len(ds.val_x), len(ds.val_y))
        self.assertEqual(len(ds.train_x) + 1, int(len(GOOD) * 0.8))
        self.assertEqual(len(ds.val_x) + 1, len(GOOD) - int(len(GOOD) * 0.8))

    def test_validation_is_the_tail_and_pairs_do_not_cross_the_split(self):
        text = "".join(chr(97 + (i % 26)) for i in range(300))
        ds = prepare_dataset(text, 0.2)
        tok = ds.tokenizer
        self.assertEqual(tok.decode([int(ds.val_x[0])]), text[240])
        self.assertEqual(tok.decode([int(ds.train_y[-1])]), text[239])

    def test_vocab_comes_from_training_part_only(self):
        text = "abc " * 100 + "Z" * 20                  # 'Z' only in the tail
        ds = prepare_dataset(text, 0.05)
        self.assertNotIn("Z", ds.tokenizer.token_to_id)
        self.assertGreater(ds.n_unk_val, 0)
        self.assertTrue(ds.warnings)

    def test_clean_split_has_no_warnings(self):
        ds = load_dataset(CORPUS)
        self.assertEqual(ds.n_unk_val, 0)
        self.assertEqual(ds.warnings, [])

    def test_deterministic_and_fingerprinted(self):
        a, b = prepare_dataset(GOOD), prepare_dataset(GOOD)
        self.assertEqual(a.sha256, b.sha256)
        self.assertTrue(np.array_equal(a.train_x, b.train_x))
        self.assertNotEqual(a.sha256, prepare_dataset(GOOD + "x").sha256)

    def test_bad_val_fraction(self):
        for bad in (0, 1, -0.5, 2):
            with self.assertRaises(DatasetError):
                prepare_dataset(GOOD, bad)

    def test_too_small_to_split(self):
        with self.assertRaises(DatasetError):
            prepare_dataset("abcdefghij", 0.1, min_chars=1)   # validation part would be 1 char

    def test_empty_input_never_reaches_training(self):
        with self.assertRaises(DatasetError):
            prepare_dataset("")


class TestLoadDatasetFromDisk(TempDirCase):
    def test_empty_file(self):
        with self.assertRaises(DatasetError):
            load_dataset(self.write("e.txt", ""))

    def test_whitespace_only_file(self):
        with self.assertRaises(DatasetError):
            load_dataset(self.write("w.txt", "  \n\n \t " * 100))

    def test_real_corpus_loads(self):
        ds = load_dataset(CORPUS)
        self.assertEqual(ds.tokenizer.vocab_size, 59)
        self.assertGreater(len(ds.train_x), 100_000)


if __name__ == "__main__":
    unittest.main()
