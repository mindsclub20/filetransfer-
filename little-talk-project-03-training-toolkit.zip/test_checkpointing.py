"""Tests for checkpointing.py (safe saving, rotation, fallback)."""

import os
import tempfile
import unittest
from unittest import mock

import numpy as np

import checkpointing
from bigram_model import BigramModel, load_checkpoint
from checkpointing import (CheckpointError, CheckpointManager,
                           save_checkpoint_atomic)
from tokenizer import CharTokenizer


def read_bytes(path):
    with open(path, "rb") as f:
        return f.read()


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.dir = self._td.name
        self.addCleanup(self._td.cleanup)
        self.tok = CharTokenizer.train("hello world")
        self.model = BigramModel(self.tok.vocab_size, seed=1)

    def at_step(self, n, seed=None):
        m = BigramModel(self.tok.vocab_size, seed=seed if seed is not None else n)
        m.steps_trained = n
        return m

    def files(self):
        return sorted(os.listdir(self.dir))


class TestAtomicSave(Base):
    def test_saves_and_loads_back(self):
        path = os.path.join(self.dir, "m.npz")
        save_checkpoint_atomic(path, self.model, self.tok, {"k": 1})
        m, t, meta = load_checkpoint(path)
        self.assertTrue(np.array_equal(m.W, self.model.W))
        self.assertEqual(meta["extra"], {"k": 1})

    def test_no_temp_files_left_after_success(self):
        save_checkpoint_atomic(os.path.join(self.dir, "m.npz"), self.model, self.tok)
        self.assertEqual(self.files(), ["m.npz"])

    @unittest.skipIf(os.name == "nt", "POSIX permissions only")
    def test_file_permissions_are_normal_not_owner_only(self):
        path = os.path.join(self.dir, "m.npz")
        save_checkpoint_atomic(path, self.model, self.tok)
        umask = os.umask(0)
        os.umask(umask)
        self.assertEqual(os.stat(path).st_mode & 0o777, 0o666 & ~umask)

    def test_creates_missing_folder(self):
        path = os.path.join(self.dir, "a", "b", "m.npz")
        save_checkpoint_atomic(path, self.model, self.tok)
        self.assertTrue(os.path.isfile(path))

    def test_failed_rename_keeps_old_checkpoint_and_cleans_up(self):
        path = os.path.join(self.dir, "m.npz")
        save_checkpoint_atomic(path, self.model, self.tok)
        before = read_bytes(path)
        newer = self.at_step(5, seed=99)
        with mock.patch("checkpointing.os.replace", side_effect=OSError("disk full")):
            with self.assertRaises(OSError):
                save_checkpoint_atomic(path, newer, self.tok)
        self.assertEqual(read_bytes(path), before)       # old file untouched
        self.assertEqual(self.files(), ["m.npz"])               # temp file removed

    def test_failed_write_keeps_old_checkpoint(self):
        path = os.path.join(self.dir, "m.npz")
        save_checkpoint_atomic(path, self.model, self.tok)
        before = read_bytes(path)
        with mock.patch("checkpointing.save_checkpoint", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                save_checkpoint_atomic(path, self.at_step(3), self.tok)
        self.assertEqual(read_bytes(path), before)
        self.assertEqual(self.files(), ["m.npz"])

    def test_verification_failure_is_not_published(self):
        path = os.path.join(self.dir, "m.npz")
        bad = BigramModel(self.tok.vocab_size, seed=2)
        with mock.patch("checkpointing.load_checkpoint", return_value=(bad, self.tok, {})):
            with self.assertRaises(CheckpointError):
                save_checkpoint_atomic(path, self.model, self.tok)
        self.assertEqual(self.files(), [])                      # nothing at the real name


class TestManager(Base):
    def test_step_file_naming_and_listing(self):
        mgr = CheckpointManager(self.dir, keep_last=5)
        self.assertEqual(mgr.list_steps(), [])
        self.assertFalse(mgr.has_checkpoints())
        mgr.save(self.at_step(200), self.tok)
        mgr.save(self.at_step(1000), self.tok)
        self.assertEqual([s for s, _ in mgr.list_steps()], [200, 1000])
        self.assertIn("step_0000200.npz", self.files())
        self.assertTrue(mgr.has_checkpoints())

    def test_rotation_keeps_only_newest(self):
        mgr = CheckpointManager(self.dir, keep_last=2)
        for s in (100, 200, 300, 400):
            mgr.save(self.at_step(s), self.tok)
        self.assertEqual([s for s, _ in mgr.list_steps()], [300, 400])

    def test_rotation_never_deletes_best(self):
        mgr = CheckpointManager(self.dir, keep_last=1)
        mgr.save_best(self.at_step(100), self.tok, {"val_loss": 1.0})
        for s in (100, 200, 300):
            mgr.save(self.at_step(s), self.tok)
        self.assertIn("best.npz", self.files())
        self.assertEqual(mgr.load_best()[0].steps_trained, 100)

    def test_load_latest_returns_newest(self):
        mgr = CheckpointManager(self.dir)
        mgr.save(self.at_step(100), self.tok)
        mgr.save(self.at_step(200), self.tok)
        self.assertEqual(mgr.load_latest()[0].steps_trained, 200)

    def test_corrupt_newest_falls_back_to_older(self):
        mgr = CheckpointManager(self.dir, keep_last=3)
        mgr.save(self.at_step(100), self.tok)
        newest = mgr.save(self.at_step(200), self.tok)
        with open(newest, "wb") as f:
            f.write(b"half-written garbage")
        loaded = mgr.load_latest()
        self.assertEqual(loaded[0].steps_trained, 100)
        self.assertEqual([os.path.basename(p) for p in mgr.skipped], ["step_0000200.npz"])

    def test_all_corrupt_or_none_returns_none(self):
        mgr = CheckpointManager(self.dir)
        self.assertIsNone(mgr.load_latest())
        self.assertIsNone(mgr.load_best())
        with open(os.path.join(self.dir, "step_0000001.npz"), "wb") as f:
            f.write(b"x")
        self.assertIsNone(mgr.load_latest())

    def test_unrelated_files_are_ignored(self):
        mgr = CheckpointManager(self.dir)
        for name in ("notes.txt", "step_12.npz", "step_abc.npz"):
            open(os.path.join(self.dir, name), "w").close()
        self.assertEqual(mgr.list_steps(), [])

    def test_bad_keep_last(self):
        with self.assertRaises(ValueError):
            CheckpointManager(self.dir, keep_last=0)


if __name__ == "__main__":
    unittest.main()
