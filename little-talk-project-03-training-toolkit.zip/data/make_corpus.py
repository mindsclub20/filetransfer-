"""Generate data/corpus.txt: a small, synthetic, original text corpus.

No downloads. Simple template-based stories with a fixed seed, so the file is
reproducible:  python data/make_corpus.py
The text is deliberately simple English. Because it is built from templates,
it is far more predictable than real writing (see README limitations).
"""
import os
import random

NAMES = ["Mia", "Sam", "Leo", "Ana", "Tom", "Ivy", "Raj", "Zoe", "Ben", "Lily"]
PLACES = ["the hill", "the river", "the market", "the old barn", "the park",
          "the garden", "the beach", "the forest", "the library", "the harbor"]
OBJECTS = ["a red kite", "a small boat", "a blue ball", "a wooden box",
           "a silver key", "a warm blanket", "a paper map", "a tiny lamp",
           "a yellow hat", "a heavy book"]
ANIMALS = ["cat", "dog", "fox", "owl", "rabbit", "horse", "duck", "goat"]
ADJ = ["quiet", "bright", "cold", "soft", "strong", "warm", "gentle", "busy"]
WEATHER = ["The sun was bright.", "A light rain began to fall.",
           "The wind was cool and fresh.", "Clouds drifted across the sky.",
           "It was a calm, quiet morning.", "Snow covered the ground."]
VERBS_GO = ["walked to", "ran to", "hurried to", "wandered to", "rode to"]
SAYS = ["said", "asked", "laughed", "whispered", "called"]
LINES = ["Let us go and see.", "Hold on tight!", "I found something strange.",
         "Do you hear that?", "We should go home soon.", "What a lovely day.",
         "Look at that!", "Wait for me!", "It is time to eat."]
ENDINGS = ["Then they went home, tired and happy.",
           "At night, everything was still.",
           "They promised to come back again.",
           "Dinner was soup, bread, and apples.",
           "The day ended with a warm light in the window."]


def story(rng):
    a, b = rng.sample(NAMES, 2)
    place, obj = rng.choice(PLACES), rng.choice(OBJECTS)
    animal, adj = rng.choice(ANIMALS), rng.choice(ADJ)
    parts = [
        rng.choice(WEATHER),
        f"{a} {rng.choice(VERBS_GO)} {place} with {obj}.",
        f"There, {a} met {b} and a {adj} {animal}.",
        f'"{rng.choice(LINES)}" {rng.choice(SAYS)} {b}.',
        f'"{rng.choice(LINES)}" {rng.choice(SAYS)} {a}.',
    ]
    if rng.random() < 0.5:
        parts.append(f"The {animal} watched {obj} for a long time.")
    if rng.random() < 0.4:
        n = rng.randint(2, 9)
        parts.append(f"They counted {n} stars, and then {n + rng.randint(1, 5)} more.")
    parts.append(rng.choice(ENDINGS))
    return " ".join(parts)


def main():
    rng = random.Random(1234)
    text = "\n\n".join(story(rng) for _ in range(450)) + "\n"
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "corpus.txt")
    with open(out, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"Wrote {out}: {len(text)} characters")


if __name__ == "__main__":
    main()
