"""Little Talk AI - Project 3: safe checkpoint handling.

Safety rules used here:
  1. Write to a temporary file in the SAME folder, flush it to disk,
  2. read it back and check it equals what we meant to save,
  3. only then atomically rename it over the final name.
A crash or error at any point leaves the previous checkpoint untouched, and
no half-written checkpoint ever has a real checkpoint name.
"""

import os
import re
import tempfile

import numpy as np

from bigram_model import load_checkpoint, save_checkpoint

STEP_RE = re.compile(r"^step_(\d{7})\.npz$")


class CheckpointError(ValueError):
    """A checkpoint could not be saved safely."""


def save_checkpoint_atomic(path, model, tokenizer, extra=None):
    """Safely write a checkpoint to `path` (see module docstring)."""
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".ckpt-", suffix=".tmp", dir=directory)
    os.close(fd)
    umask = os.umask(0)
    os.umask(umask)
    os.chmod(tmp, 0o666 & ~umask)                          # normal permissions, not mkstemp's 0600
    try:
        save_checkpoint(tmp, model, tokenizer, extra)
        with open(tmp, "rb+") as f:
            f.flush()
            os.fsync(f.fileno())
        back, back_tok, _ = load_checkpoint(tmp)          # verify what hit the disk
        if not np.array_equal(back.W, model.W) or back_tok.id_to_token != tokenizer.id_to_token:
            raise CheckpointError("Checkpoint failed verification after writing")
        os.replace(tmp, path)                              # atomic on the same filesystem
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return path


class CheckpointManager:
    """Keeps `step_0000200.npz`-style files plus a `best.npz` in one folder."""

    def __init__(self, directory, keep_last=3):
        if keep_last < 1:
            raise ValueError("keep_last must be at least 1")
        self.directory = directory
        self.keep_last = keep_last
        self.skipped = []   # corrupt files skipped by load_latest()

    @property
    def best_path(self):
        return os.path.join(self.directory, "best.npz")

    def list_steps(self):
        """Sorted list of (step, path) for every step checkpoint present."""
        if not os.path.isdir(self.directory):
            return []
        found = []
        for name in os.listdir(self.directory):
            m = STEP_RE.match(name)
            if m:
                found.append((int(m.group(1)), os.path.join(self.directory, name)))
        return sorted(found)

    def has_checkpoints(self):
        return bool(self.list_steps()) or os.path.exists(self.best_path)

    def save(self, model, tokenizer, extra=None):
        """Save a step checkpoint, then delete the oldest ones beyond keep_last."""
        path = os.path.join(self.directory, f"step_{model.steps_trained:07d}.npz")
        save_checkpoint_atomic(path, model, tokenizer, extra)
        for _, old in self.list_steps()[:-self.keep_last]:
            os.remove(old)
        return path

    def save_best(self, model, tokenizer, extra=None):
        return save_checkpoint_atomic(self.best_path, model, tokenizer, extra)

    def load_latest(self):
        """Newest VALID step checkpoint as (model, tokenizer, meta), else None.

        A corrupt newest file is skipped (and listed in self.skipped) so an
        older good checkpoint can still be used.
        """
        self.skipped = []
        for _, path in reversed(self.list_steps()):
            try:
                return load_checkpoint(path)
            except ValueError:
                self.skipped.append(path)
        return None

    def load_best(self):
        if not os.path.exists(self.best_path):
            return None
        try:
            return load_checkpoint(self.best_path)
        except ValueError:
            return None
