"""Little Talk AI - Project 3: reading, checking and splitting training data.

Every problem with the input raises DatasetError with a plain-English message,
so a bad file stops the run early instead of producing a meaningless model.
"""

import hashlib
import os
from dataclasses import dataclass, field
from typing import List

import numpy as np

from bigram_model import make_pairs, split_ids
from tokenizer import CharTokenizer

DEFAULT_MAX_BYTES = 50_000_000   # refuse huge inputs (protects limited RAM)
DEFAULT_MIN_CHARS = 100          # refuse inputs too short to train/validate on


class DatasetError(ValueError):
    """The training data is missing, empty, unreadable or unusable."""


@dataclass
class Dataset:
    tokenizer: CharTokenizer
    train_x: np.ndarray
    train_y: np.ndarray
    val_x: np.ndarray
    val_y: np.ndarray
    n_chars: int
    sha256: str                      # fingerprint of the exact text used
    n_unk_val: int = 0               # validation characters unseen in training
    warnings: List[str] = field(default_factory=list)


def load_text(path, max_bytes=DEFAULT_MAX_BYTES):
    """Read a UTF-8 text file, or every *.txt file in a folder (sorted by name).

    Line endings are normalised to \\n and a UTF-8 BOM is dropped.
    """
    if not os.path.exists(path):
        raise DatasetError(f"Data path does not exist: {path}")
    if os.path.isdir(path):
        names = sorted(n for n in os.listdir(path)
                       if n.lower().endswith(".txt") and os.path.isfile(os.path.join(path, n)))
        if not names:
            raise DatasetError(f"No .txt files found in folder: {path}")
        files = [os.path.join(path, n) for n in names]
    else:
        files = [path]

    total = sum(os.path.getsize(f) for f in files)
    if total > max_bytes:
        raise DatasetError(f"Data is {total} bytes, over the limit of {max_bytes} bytes")

    texts = []
    for f in files:
        try:
            with open(f, "rb") as fh:
                raw = fh.read()
        except OSError as e:
            raise DatasetError(f"Cannot read {f}: {e}") from e
        if b"\x00" in raw:
            raise DatasetError(f"{f} looks like a binary file (contains NUL bytes)")
        try:
            texts.append(raw.decode("utf-8-sig"))
        except UnicodeDecodeError as e:
            raise DatasetError(f"{f} is not valid UTF-8 text: {e}") from e
    return "\n".join(texts).replace("\r\n", "\n").replace("\r", "\n")


def validate_text(text, min_chars=DEFAULT_MIN_CHARS):
    """Raise DatasetError unless the text is usable."""
    if not isinstance(text, str):
        raise DatasetError("Training data must be text")
    if not text.strip():
        raise DatasetError("Training data is empty (or only whitespace)")
    if len(text) < min_chars:
        raise DatasetError(f"Training data has only {len(text)} characters; need at least {min_chars}")
    if len(set(text)) < 2:
        raise DatasetError("Training data has only one distinct character")


def prepare_dataset(text, val_fraction=0.1, min_chars=DEFAULT_MIN_CHARS):
    """Validate, split and tokenize. The split is contiguous: validation is the tail.

    The vocabulary is built from the TRAINING part only, so a character that
    first appears in validation is encoded as <unk> (and counted below).
    """
    validate_text(text, min_chars)
    if not 0.0 < val_fraction < 1.0:
        raise DatasetError("val_fraction must be between 0 and 1 (exclusive)")

    cut = int(len(text) * (1.0 - val_fraction))
    if cut < 2 or len(text) - cut < 2:
        raise DatasetError("Data is too small to split into training and validation parts")

    tok = CharTokenizer.train(text[:cut])
    train_ids, val_ids = split_ids(tok.encode(text), val_fraction)
    train_x, train_y = make_pairs(train_ids)
    val_x, val_y = make_pairs(val_ids)

    n_unk = sum(1 for i in val_ids if i == tok.unk_id)
    warnings = []
    if n_unk / len(val_ids) > 0.01:
        warnings.append(f"{n_unk} of {len(val_ids)} validation characters are unseen in training "
                        f"(<unk>); validation loss may be unreliable")
    return Dataset(
        tokenizer=tok, train_x=train_x, train_y=train_y, val_x=val_x, val_y=val_y,
        n_chars=len(text), sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        n_unk_val=n_unk, warnings=warnings)


def load_dataset(path, val_fraction=0.1, min_chars=DEFAULT_MIN_CHARS, max_bytes=DEFAULT_MAX_BYTES):
    """Convenience: load_text + prepare_dataset."""
    return prepare_dataset(load_text(path, max_bytes), val_fraction, min_chars)
