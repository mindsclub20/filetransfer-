"""Little Talk AI - Project 3: the training loop with safe checkpoints and resume.

Reproducibility: the random batch for step N is drawn from a generator seeded
with [seed, 1, N]. It depends only on the seed and the step number, so a run
that is stopped and resumed produces EXACTLY the same weights as one that was
never stopped (a unit test checks this).
"""

import math
import os
from dataclasses import asdict, dataclass

import numpy as np

from bigram_model import BigramModel
from checkpointing import CheckpointManager


class TrainingError(ValueError):
    """Training could not continue (bad settings or a non-finite loss)."""


class ResumeError(ValueError):
    """The checkpoint folder cannot be used for this run."""


@dataclass
class TrainConfig:
    steps: int = 2000             # total steps to reach (including steps already done)
    batch_size: int = 4096
    lr: float = 20.0
    seed: int = 42
    val_fraction: float = 0.1
    eval_every: int = 200
    checkpoint_every: int = 500
    keep_last: int = 3
    init_std: float = 0.02

    def validate(self):
        if self.steps < 1:
            raise TrainingError("steps must be at least 1")
        if self.batch_size < 1:
            raise TrainingError("batch_size must be at least 1")
        if not self.lr > 0:
            raise TrainingError("lr must be greater than 0")
        if self.eval_every < 1 or self.checkpoint_every < 1:
            raise TrainingError("eval_every and checkpoint_every must be at least 1")
        if self.keep_last < 1:
            raise TrainingError("keep_last must be at least 1")


def _batch(dataset, config, step):
    rng = np.random.default_rng([config.seed, 1, step])
    n = len(dataset.train_x)
    idx = rng.integers(0, n, size=min(config.batch_size, n))
    return dataset.train_x[idx], dataset.train_y[idx]


def _check_finite(value, what, step):
    if not math.isfinite(value):
        raise TrainingError(f"{what} became {value} at step {step}; stopping "
                            f"(try a smaller learning rate). Checkpoints were not overwritten.")


def run_training(dataset, config, out_dir, logger, resume=False):
    """Train, log, and checkpoint into `out_dir/checkpoints`.

    Returns a dict: model, history [(step, train, val)], best_val, final_step.
    """
    config.validate()
    tok = dataset.tokenizer
    manager = CheckpointManager(os.path.join(out_dir, "checkpoints"), config.keep_last)
    signature = {"data_sha256": dataset.sha256, "seed": config.seed,
                 "val_fraction": config.val_fraction, "batch_size": config.batch_size}

    if manager.has_checkpoints() and not resume:
        raise ResumeError(f"{manager.directory} already contains checkpoints. "
                          f"Use resume, or choose an empty output folder.")

    best_val = math.inf
    history = []
    if resume:
        loaded = manager.load_latest()
        if loaded is None:
            raise ResumeError(f"No valid checkpoint to resume from in {manager.directory}")
        model, ck_tok, meta = loaded
        for path in manager.skipped:
            logger.message(f"WARNING: skipped unreadable checkpoint {os.path.basename(path)}")
        if ck_tok.id_to_token != tok.id_to_token:
            raise ResumeError("Checkpoint vocabulary does not match this data")
        saved = meta.get("extra", {}).get("signature", {})
        bad = [k for k, v in signature.items() if saved.get(k) != v]
        if bad:
            raise ResumeError("Checkpoint was made with different " + ", ".join(bad))
        if meta.get("extra", {}).get("lr") != config.lr:
            logger.message(f"WARNING: lr changed since the checkpoint "
                           f"({meta.get('extra', {}).get('lr')} -> {config.lr})")
        best = manager.load_best()
        if best is not None:
            best_val = best[2].get("extra", {}).get("val_loss", math.inf)
        logger.message(f"Resuming from step {model.steps_trained}")
    else:
        model = BigramModel(tok.vocab_size, seed=config.seed, init_std=config.init_std)

    if model.steps_trained >= config.steps:
        logger.message(f"Already trained for {model.steps_trained} steps (target {config.steps}); nothing to do.")
        return {"model": model, "history": history, "best_val": best_val,
                "final_step": model.steps_trained}

    def extra_for(train_loss, val_loss):
        return {"signature": signature, "lr": config.lr, "config": asdict(config),
                "train_loss": train_loss, "val_loss": val_loss}

    def evaluate():
        nonlocal best_val
        step = model.steps_trained
        tl = model.loss(dataset.train_x, dataset.train_y)
        vl = model.loss(dataset.val_x, dataset.val_y)
        _check_finite(tl, "train loss", step)
        _check_finite(vl, "validation loss", step)
        history.append((step, tl, vl))
        logger.metrics(step, tl, vl)
        if vl < best_val:
            best_val = vl
            manager.save_best(model, tok, extra_for(tl, vl))
        return tl, vl

    saved_at = model.steps_trained if resume else -1
    if not resume:
        evaluate()                                  # loss before any training
    try:
        while model.steps_trained < config.steps:
            step = model.steps_trained + 1
            x, y = _batch(dataset, config, step)
            _check_finite(model.sgd_step(x, y, config.lr), "batch loss", step)
            last = step == config.steps
            if step % config.eval_every == 0 or last:
                tl, vl = evaluate()
            if step % config.checkpoint_every == 0 or last:
                tl, vl = (history[-1][1], history[-1][2]) if history and history[-1][0] == step \
                    else (model.loss(dataset.train_x, dataset.train_y),
                          model.loss(dataset.val_x, dataset.val_y))
                manager.save(model, tok, extra_for(tl, vl))
                saved_at = step
    except KeyboardInterrupt:
        if model.steps_trained != saved_at and model.steps_trained > 0:
            tl = model.loss(dataset.train_x, dataset.train_y)
            vl = model.loss(dataset.val_x, dataset.val_y)
            if math.isfinite(tl) and math.isfinite(vl):
                manager.save(model, tok, extra_for(tl, vl))
                logger.message(f"Interrupted: saved checkpoint at step {model.steps_trained}")
        raise
    return {"model": model, "history": history, "best_val": best_val,
            "final_step": model.steps_trained}
