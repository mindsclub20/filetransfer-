"""Tests for trainer.py and logger.py: logging, seeds, resume, safety."""

import math
import os
import tempfile
import unittest

import numpy as np

from bigram_model import BigramModel
from dataset import load_dataset, prepare_dataset
from logger import MetricsLogger
from trainer import (ResumeError, TrainConfig, TrainingError, run_training)

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "data", "corpus.txt")


def read(path, mode="r"):
    with open(path, mode) as f:
        return f.read()


TEXT = read(CORPUS)[:20000]


def make_cfg(**kw):
    base = dict(steps=60, batch_size=512, lr=20.0, seed=7, eval_every=20, checkpoint_every=30)
    base.update(kw)
    return TrainConfig(**base)


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.dir = self._td.name
        self.addCleanup(self._td.cleanup)
        self.ds = prepare_dataset(TEXT, 0.1)

    def run_it(self, cfg, sub="run", resume=False, ds=None):
        out = os.path.join(self.dir, sub)
        os.makedirs(out, exist_ok=True)
        log = MetricsLogger(os.path.join(out, "train.log"), os.path.join(out, "metrics.csv"),
                            append=resume, echo=False)
        try:
            return run_training(ds or self.ds, cfg, out, log, resume=resume)
        finally:
            log.close()


class TestTrainingBasics(Base):
    def test_loss_starts_near_uniform_and_drops(self):
        res = self.run_it(make_cfg(steps=100))
        h = res["history"]
        self.assertEqual(h[0][0], 0)
        self.assertAlmostEqual(h[0][2], math.log(self.ds.tokenizer.vocab_size), delta=0.05)
        self.assertLess(h[-1][1], h[0][1] - 1.0)
        self.assertLess(h[-1][2], h[0][2] - 1.0)
        self.assertEqual(res["final_step"], 100)

    def test_eval_happens_at_regular_intervals(self):
        res = self.run_it(make_cfg(steps=50, eval_every=20))
        self.assertEqual([s for s, _, _ in res["history"]], [0, 20, 40, 50])

    def test_logs_are_written(self):
        self.run_it(make_cfg(steps=40, eval_every=20))
        out = os.path.join(self.dir, "run")
        csv_lines = read(os.path.join(out, "metrics.csv")).strip().splitlines()
        self.assertEqual(csv_lines[0], "step,train_loss,val_loss,val_perplexity,seconds")
        self.assertEqual([l.split(",")[0] for l in csv_lines[1:]], ["0", "20", "40"])
        text = read(os.path.join(out, "train.log"))
        self.assertIn("step      20 | train loss", text)

    def test_checkpoints_written_on_schedule_and_at_end(self):
        self.run_it(make_cfg(steps=70, checkpoint_every=30, keep_last=5))
        names = sorted(os.listdir(os.path.join(self.dir, "run", "checkpoints")))
        self.assertEqual(names, ["best.npz", "step_0000030.npz", "step_0000060.npz", "step_0000070.npz"])

    def test_best_checkpoint_has_lowest_validation_loss(self):
        res = self.run_it(make_cfg(steps=80))
        from checkpointing import CheckpointManager
        best = CheckpointManager(os.path.join(self.dir, "run", "checkpoints")).load_best()
        self.assertAlmostEqual(best[2]["extra"]["val_loss"], min(v for _, _, v in res["history"]), places=9)

    def test_bad_settings_rejected(self):
        for kw in ({"steps": 0}, {"batch_size": 0}, {"lr": 0}, {"lr": -1},
                   {"eval_every": 0}, {"checkpoint_every": 0}, {"keep_last": 0}):
            with self.assertRaises(TrainingError, msg=str(kw)):
                self.run_it(make_cfg(**kw), sub="bad" + str(len(kw)) + str(sorted(kw.values())))


class TestReproducibility(Base):
    def test_batches_depend_on_step_and_seed_but_are_repeatable(self):
        from trainer import _batch
        cfg = make_cfg()
        x1, _ = _batch(self.ds, cfg, 1)
        self.assertTrue(np.array_equal(x1, _batch(self.ds, cfg, 1)[0]))       # repeatable
        self.assertFalse(np.array_equal(x1, _batch(self.ds, cfg, 2)[0]))      # varies by step
        self.assertFalse(np.array_equal(x1, _batch(self.ds, make_cfg(seed=8), 1)[0]))  # and by seed

    def test_same_seed_gives_identical_weights_and_losses(self):
        a = self.run_it(make_cfg(), sub="a")
        b = self.run_it(make_cfg(), sub="b")
        self.assertTrue(np.array_equal(a["model"].W, b["model"].W))
        self.assertEqual(a["history"], b["history"])

    def test_different_seed_differs(self):
        a = self.run_it(make_cfg(seed=1), sub="a")
        b = self.run_it(make_cfg(seed=2), sub="b")
        self.assertFalse(np.array_equal(a["model"].W, b["model"].W))

    def test_resumed_run_equals_uninterrupted_run_exactly(self):
        straight = self.run_it(make_cfg(steps=90), sub="straight")
        self.run_it(make_cfg(steps=40, checkpoint_every=40), sub="split")
        resumed = self.run_it(make_cfg(steps=90), sub="split", resume=True)
        self.assertEqual(resumed["final_step"], 90)
        self.assertTrue(np.array_equal(straight["model"].W, resumed["model"].W))
        # the appended CSV has one header and continuous steps
        lines = read(os.path.join(self.dir, "split", "metrics.csv")).strip().splitlines()
        self.assertEqual(sum(l.startswith("step,") for l in lines), 1)
        steps = [int(l.split(",")[0]) for l in lines[1:]]
        self.assertEqual(steps, sorted(set(steps)))


class TestResumeSafety(Base):
    def test_refuses_to_overwrite_existing_run(self):
        self.run_it(make_cfg(steps=20, checkpoint_every=20), sub="r")
        with self.assertRaises(ResumeError):
            self.run_it(make_cfg(steps=20), sub="r")

    def test_resume_without_checkpoint(self):
        with self.assertRaises(ResumeError):
            self.run_it(make_cfg(), sub="empty", resume=True)

    def test_resume_with_different_data_seed_or_batch_is_refused(self):
        self.run_it(make_cfg(steps=20, checkpoint_every=20), sub="r")
        with self.assertRaises(ResumeError):
            self.run_it(make_cfg(steps=40, seed=8), sub="r", resume=True)
        with self.assertRaises(ResumeError):
            self.run_it(make_cfg(steps=40, batch_size=256), sub="r", resume=True)
        other = prepare_dataset(TEXT[:15000], 0.1)
        with self.assertRaises(ResumeError):
            self.run_it(make_cfg(steps=40), sub="r", resume=True, ds=other)

    def test_resume_after_target_reached_does_nothing(self):
        a = self.run_it(make_cfg(steps=20, checkpoint_every=20), sub="r")
        b = self.run_it(make_cfg(steps=20), sub="r", resume=True)
        self.assertEqual(b["final_step"], 20)
        self.assertTrue(np.array_equal(a["model"].W, b["model"].W))

    def test_resume_skips_corrupt_newest_checkpoint(self):
        self.run_it(make_cfg(steps=60, checkpoint_every=30, keep_last=3), sub="r")
        newest = os.path.join(self.dir, "r", "checkpoints", "step_0000060.npz")
        with open(newest, "wb") as f:
            f.write(b"corrupt")
        res = self.run_it(make_cfg(steps=90), sub="r", resume=True)
        self.assertEqual(res["final_step"], 90)
        straight = self.run_it(make_cfg(steps=90), sub="s")
        self.assertTrue(np.array_equal(res["model"].W, straight["model"].W))


class TestFailureHandling(Base):
    def test_non_finite_loss_stops_without_overwriting_checkpoints(self):
        self.run_it(make_cfg(steps=30, checkpoint_every=30), sub="r")
        ck = os.path.join(self.dir, "r", "checkpoints")
        before = {n: read(os.path.join(ck, n), "rb") for n in os.listdir(ck)}
        orig = BigramModel.sgd_step

        def poisoned(self_, x, y, lr):
            orig(self_, x, y, lr)
            return float("nan")

        BigramModel.sgd_step = poisoned
        try:
            with self.assertRaises(TrainingError):
                self.run_it(make_cfg(steps=60), sub="r", resume=True)
        finally:
            BigramModel.sgd_step = orig
        after = {n: read(os.path.join(ck, n), "rb") for n in os.listdir(ck)}
        self.assertEqual(before, after)

    def test_keyboard_interrupt_saves_a_checkpoint(self):
        orig = BigramModel.sgd_step

        def interrupt(self_, x, y, lr):
            if self_.steps_trained == 12:
                raise KeyboardInterrupt
            return orig(self_, x, y, lr)

        BigramModel.sgd_step = interrupt
        try:
            with self.assertRaises(KeyboardInterrupt):
                self.run_it(make_cfg(steps=100, checkpoint_every=50), sub="r")
        finally:
            BigramModel.sgd_step = orig
        res = self.run_it(make_cfg(steps=30), sub="r", resume=True)
        straight = self.run_it(make_cfg(steps=30), sub="s")
        self.assertTrue(np.array_equal(res["model"].W, straight["model"].W))

    def test_real_corpus_end_to_end_beats_uniform(self):
        ds = load_dataset(CORPUS)
        res = self.run_it(make_cfg(steps=60, batch_size=2048), ds=ds)
        self.assertLess(res["history"][-1][2], math.log(ds.tokenizer.vocab_size) - 1.0)


if __name__ == "__main__":
    unittest.main()
