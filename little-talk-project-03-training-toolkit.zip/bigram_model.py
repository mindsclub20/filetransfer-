"""Little Talk AI - Project 2: a character-level bigram language model.

A bigram model predicts the next character from ONLY the current character.
Its entire "brain" is one table W of shape (vocab, vocab):

    row i of W = the raw scores (logits) for what comes after character i

    P(next = j | current = i) = softmax(W[i])[j]

W is initialised with small random numbers and trained with gradient descent
on cross-entropy loss. The gradient is derived by hand (no autograd library).

Only NumPy is used. No pretrained weights, no external AI APIs.
"""

import json

import numpy as np

from tokenizer import SPECIAL_TOKENS, CharTokenizer

CHECKPOINT_VERSION = 1
EVAL_CHUNK = 50_000  # rows scored at once, keeps memory small on big corpora


# ---------------------------------------------------------------------------
# data helpers
# ---------------------------------------------------------------------------
def split_ids(ids, val_fraction=0.1):
    """Split a token-ID list into (train, val). Contiguous: val is the tail."""
    if not 0.0 < val_fraction < 1.0:
        raise ValueError("val_fraction must be between 0 and 1 (exclusive)")
    cut = int(len(ids) * (1.0 - val_fraction))
    return ids[:cut], ids[cut:]


def make_pairs(ids):
    """Return (inputs, targets): each character paired with the one after it."""
    arr = np.asarray(ids, dtype=np.int64)
    if arr.ndim != 1:
        raise ValueError("ids must be a flat list of integers")
    return arr[:-1], arr[1:]


def log_softmax(logits):
    """Numerically stable log-softmax over the last axis."""
    z = logits - logits.max(axis=-1, keepdims=True)
    return z - np.log(np.exp(z).sum(axis=-1, keepdims=True))


# ---------------------------------------------------------------------------
# the model
# ---------------------------------------------------------------------------
class BigramModel:
    def __init__(self, vocab_size, seed=0, init_std=0.02):
        if vocab_size < 1:
            raise ValueError("vocab_size must be positive")
        self.vocab_size = int(vocab_size)
        self.seed = int(seed)
        self.init_std = float(init_std)
        self.steps_trained = 0
        # [seed, 0] = stream for initial weights (other streams are used for
        # batch sampling and text generation, so they never overlap).
        rng = np.random.default_rng([self.seed, 0])
        self.W = rng.normal(0.0, self.init_std, size=(self.vocab_size, self.vocab_size))

    # ---- probabilities and loss ---------------------------------------
    def next_char_probs(self, token_id):
        """Probability distribution over the next token, given `token_id`."""
        self._check_id(token_id)
        return np.exp(log_softmax(self.W[token_id]))

    def loss(self, x, y):
        """Mean cross-entropy (nats per character) over all pairs, in chunks."""
        x, y = self._check_pairs(x, y)
        total = 0.0
        for s in range(0, len(x), EVAL_CHUNK):
            xs, ys = x[s:s + EVAL_CHUNK], y[s:s + EVAL_CHUNK]
            logp = log_softmax(self.W[xs])
            total += -logp[np.arange(len(xs)), ys].sum()
        return float(total / len(x))

    def loss_and_grad(self, x, y):
        """Mean loss and its gradient with respect to W (derived by hand).

        For each pair (x_n, y_n):  dLoss/dW[x_n] = softmax(W[x_n]) - onehot(y_n)
        averaged over the N pairs in the batch.
        """
        x, y = self._check_pairs(x, y)
        n = len(x)
        logp = log_softmax(self.W[x])
        loss = float(-logp[np.arange(n), y].mean())
        d = np.exp(logp)
        d[np.arange(n), y] -= 1.0
        d /= n
        grad = np.zeros_like(self.W)
        np.add.at(grad, x, d)  # rows used several times are summed correctly
        return loss, grad

    def sgd_step(self, x, y, lr):
        """One plain gradient-descent update. Returns the batch loss."""
        loss, grad = self.loss_and_grad(x, y)
        self.W -= lr * grad
        self.steps_trained += 1
        return loss

    # ---- generation ---------------------------------------------------
    def generate_ids(self, start_id, length, temperature=1.0, seed=0, banned_ids=()):
        """Sample `length` new token IDs after `start_id`. Same seed -> same output.

        temperature < 1 is more cautious, > 1 is more random. IDs in
        `banned_ids` (e.g. special tokens) are never sampled.
        """
        self._check_id(start_id)
        if length < 0:
            raise ValueError("length must be >= 0")
        if not temperature > 0:
            raise ValueError("temperature must be greater than 0")
        rng = np.random.default_rng([int(seed), 2])
        banned = list(banned_ids)
        out, cur = [], start_id
        for _ in range(length):
            logits = self.W[cur] / temperature
            if banned:
                logits = logits.copy()
                logits[banned] = -np.inf
            p = np.exp(log_softmax(logits))
            cur = int(rng.choice(self.vocab_size, p=p))
            out.append(cur)
        return out

    # ---- internals ----------------------------------------------------
    def _check_id(self, i):
        if not 0 <= int(i) < self.vocab_size:
            raise ValueError(f"Token ID {i} is out of range (vocab size {self.vocab_size})")

    def _check_pairs(self, x, y):
        x = np.asarray(x, dtype=np.int64)
        y = np.asarray(y, dtype=np.int64)
        if x.shape != y.shape or x.ndim != 1:
            raise ValueError("x and y must be 1-D arrays of the same length")
        if len(x) == 0:
            raise ValueError("Need at least one (current, next) pair")
        if x.min() < 0 or y.min() < 0 or x.max() >= self.vocab_size or y.max() >= self.vocab_size:
            raise ValueError("Token IDs out of range for this model")
        return x, y


def generate_text(model, tokenizer, start_char, length, temperature=1.0, seed=0):
    """Generate text that begins with `start_char`.

    Raises ValueError if `start_char` is not exactly one character that the
    tokenizer knows (special tokens do not count).
    """
    if not isinstance(start_char, str) or len(start_char) != 1:
        raise ValueError("start_char must be exactly one character")
    start_id = tokenizer.token_to_id.get(start_char)
    if start_id is None or start_char in SPECIAL_TOKENS:
        raise ValueError(f"Starting character {start_char!r} is not in the vocabulary")
    banned = [tokenizer.pad_id, tokenizer.unk_id, tokenizer.bos_id, tokenizer.eos_id]
    ids = model.generate_ids(start_id, length, temperature, seed, banned)
    return start_char + tokenizer.decode(ids)


# ---------------------------------------------------------------------------
# reference: the count-based bigram model (used as a sanity check)
# ---------------------------------------------------------------------------
def count_bigram_loss(train_x, train_y, eval_x, eval_y, vocab_size, alpha=1.0):
    """Loss of a bigram model built by simply COUNTING pairs (add-alpha smoothing).

    Gradient descent on a bigram table should approach this value, so it makes
    a good "is training working?" reference. It is not used by the model.
    """
    counts = np.full((vocab_size, vocab_size), float(alpha))
    np.add.at(counts, (np.asarray(train_x), np.asarray(train_y)), 1.0)
    probs = counts / counts.sum(axis=1, keepdims=True)
    ex, ey = np.asarray(eval_x), np.asarray(eval_y)
    return float(-np.log(probs[ex, ey]).mean())


# ---------------------------------------------------------------------------
# checkpoints (a single .npz file; no pickle, so loading is safe)
# ---------------------------------------------------------------------------
def save_checkpoint(path, model, tokenizer, extra=None):
    """Save weights + vocabulary + settings to one file."""
    meta = {
        "format_version": CHECKPOINT_VERSION,
        "model": "bigram",
        "tokens": tokenizer.id_to_token,
        "seed": model.seed,
        "init_std": model.init_std,
        "steps_trained": model.steps_trained,
        "extra": extra or {},
    }
    with open(path, "wb") as f:  # file object => numpy won't rename the file
        np.savez(f, W=model.W, meta=np.array(json.dumps(meta, ensure_ascii=False)))


def load_checkpoint(path):
    """Load a checkpoint. Returns (model, tokenizer, meta). Raises ValueError if invalid."""
    try:
        data = np.load(path, allow_pickle=False)
        files = set(data.files)
        if not {"W", "meta"} <= files:
            raise ValueError("Checkpoint is missing 'W' or 'meta'")
        W = data["W"]
        meta = json.loads(str(data["meta"]))
    except FileNotFoundError:
        raise
    except ValueError as e:
        raise ValueError(f"Not a valid checkpoint: {e}") from e
    except Exception as e:  # corrupt zip, bad json, pickled content, ...
        raise ValueError(f"Not a valid checkpoint: {e}") from e

    if meta.get("model") != "bigram" or meta.get("format_version") != CHECKPOINT_VERSION:
        raise ValueError("Unsupported checkpoint type or version")
    tokens = meta.get("tokens")
    if not isinstance(tokens, list) or tokens[:len(SPECIAL_TOKENS)] != SPECIAL_TOKENS:
        raise ValueError("Checkpoint vocabulary is invalid")
    tokenizer = CharTokenizer(tokens[len(SPECIAL_TOKENS):])  # validates entries
    v = tokenizer.vocab_size
    if W.shape != (v, v) or not np.issubdtype(W.dtype, np.floating):
        raise ValueError(f"Weight shape {W.shape} does not match vocabulary size {v}")
    if not np.isfinite(W).all():
        raise ValueError("Weights contain NaN or infinity")

    model = BigramModel(v, seed=int(meta.get("seed", 0)), init_std=float(meta.get("init_std", 0.02)))
    model.W = W.astype(np.float64)
    model.steps_trained = int(meta.get("steps_trained", 0))
    return model, tokenizer, meta
