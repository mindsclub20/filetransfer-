"""Generate text from a trained checkpoint.

    python generate.py --checkpoint runs/demo --start T --length 300 --seed 1
    python generate.py --checkpoint runs/demo --best --start M
    python generate.py --checkpoint runs/demo/checkpoints/best.npz --start T

--checkpoint may be a .npz file, a run folder, or its checkpoints folder.
For a folder, the newest valid step checkpoint is used (or best.npz with --best).
"""

import argparse
import os
import sys

from bigram_model import generate_text, load_checkpoint
from checkpointing import CheckpointManager


def load_from(path, best=False):
    """Return (model, tokenizer, meta) for a file or run folder."""
    if os.path.isdir(path):
        ckdir = os.path.join(path, "checkpoints")
        manager = CheckpointManager(ckdir if os.path.isdir(ckdir) else path)
        loaded = manager.load_best() if best else manager.load_latest()
        if loaded is None:
            raise ValueError(f"No usable {'best' if best else 'step'} checkpoint in {path}")
        return loaded
    return load_checkpoint(path)


def main(argv=None):
    p = argparse.ArgumentParser(description="Generate text with a trained bigram model.")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--start", required=True, help="one starting character")
    p.add_argument("--length", type=int, default=300)
    p.add_argument("--temperature", type=float, default=1.0)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--count", type=int, default=1, help="how many samples (seeds seed, seed+1, ...)")
    p.add_argument("--best", action="store_true", help="use best.npz (lowest validation loss)")
    args = p.parse_args(argv)
    try:
        model, tok, _ = load_from(args.checkpoint, args.best)
        for k in range(max(1, args.count)):
            if args.count > 1:
                print(f"--- sample {k + 1} (seed {args.seed + k}) ---")
            print(generate_text(model, tok, args.start, args.length, args.temperature, args.seed + k))
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
