# Little Talk AI - Project 3: Training Toolkit

A small, CPU-friendly toolkit around the from-scratch character-level bigram model
from Project 2. It reads local text, checks it, splits it, trains with regular
loss logging, saves checkpoints safely, can resume an interrupted run exactly,
and generates text from a saved checkpoint.

- No pretrained models, no external AI APIs, no downloads. Python 3.8+ and NumPy only.
- Still Project 3 only: the model itself is unchanged (`bigram_model.py`, `tokenizer.py`).

## Files

| File | Purpose |
|------|---------|
| `dataset.py` | Read local data (file or folder of `.txt`), validate it, split train/validation, tokenize |
| `checkpointing.py` | Safe (atomic, verified) saving, rotation, best checkpoint, fallback past corrupt files |
| `logger.py` | Readable text log + CSV of losses |
| `trainer.py` | Training loop: seeds, evaluation schedule, checkpoint schedule, resume, failure handling |
| `run_training.py` | Command-line trainer |
| `generate.py` | Command-line text generator |
| `tokenizer.py`, `bigram_model.py` | Project 1 tokenizer and Project 2 model (unchanged) |
| `train.py` | Project 2's simple trainer, kept unchanged so Project 2's tests still run. Use `run_training.py` instead |
| `test_*.py` | 120 automated tests (see below) |
| `data/corpus.txt` | Training corpus, 113,899 characters (synthetic; `data/make_corpus.py` recreates it exactly) |
| `data/sample.txt` | Tiny corpus from Project 1 (used by the tokenizer tests) |
| `runs/demo/` | Output of the logged training run (checkpoints, `train.log`, `metrics.csv`, `config.json`) |
| `training_log.txt` | Copy of `runs/demo/train.log` |

## Setup

```
pip install -r requirements.txt
```

## Run the tests

```
python -m unittest -v
```

A passing run ends with `Ran 120 tests ... OK` (about 4 seconds).

| Test file | Tests | Covers |
|-----------|------:|--------|
| `test_tokenizer.py` | 24 | Project 1 tokenizer |
| `test_bigram.py` | 29 | Project 2 model, gradient, generation, checkpoints |
| `test_dataset.py` | 23 | Reading, bad/empty/binary/non-UTF-8/oversized data, splitting |
| `test_checkpointing.py` | 15 | Atomic saving, failed writes, rotation, corrupt-file fallback, permissions |
| `test_trainer.py` | 18 | Logging intervals, seeds, exact resume, resume safety, NaN stop, Ctrl+C |
| `test_cli.py` | 11 | The two scripts end to end, exit codes, error messages |

## Train

```
python run_training.py --data data/corpus.txt --out-dir runs/demo --steps 2000 --seed 42
```

Options: `--batch-size` (4096), `--lr` (20), `--val-fraction` (0.1), `--eval-every` (200),
`--checkpoint-every` (500), `--keep-last` (3), `--min-chars` (100), `--max-bytes` (50,000,000).
`--data` may be one UTF-8 text file or a folder of `.txt` files (read in name order).

Output in `--out-dir`: `train.log`, `metrics.csv`, `config.json`, and `checkpoints/`
(`step_0000500.npz` ..., plus `best.npz`, the lowest validation loss seen).

### Resume

`--steps` is the TOTAL number of steps to reach. To continue an earlier run, repeat the
command with a larger `--steps` and add `--resume`:

```
python run_training.py --data data/corpus.txt --out-dir runs/demo --steps 4000 --seed 42 --resume
```

Pressing Ctrl+C during training saves a checkpoint first. Running into an existing
`--out-dir` without `--resume` is refused, before any file is touched.

## Generate

```
python generate.py --checkpoint runs/demo --start T --length 300 --seed 1
python generate.py --checkpoint runs/demo --best --start M --count 3
python generate.py --checkpoint runs/demo/checkpoints/best.npz --start T
```

`--checkpoint` can be a run folder (newest valid checkpoint, or `best.npz` with `--best`),
or a single `.npz` file. `--start` must be one character seen in training. Bad input
gives a one-line error and exit status 1.

## What counts as invalid data

Each of these stops the run with a plain error message (exit status 2), before any
model, log or checkpoint is created: path does not exist; folder with no `.txt`
files; empty or whitespace-only text; fewer than `--min-chars` characters; only one
distinct character; binary content (NUL bytes); invalid UTF-8; larger than `--max-bytes`;
a split that would leave under 2 characters for training or validation; `val_fraction`
outside (0, 1). A warning (not an error) is logged if more than 1% of validation
characters are unseen in training.

## How checkpoints are kept safe

1. Write to a temporary file in the same folder and flush it to disk.
2. Read it back and confirm weights and vocabulary match what was meant to be saved.
3. Only then atomically rename it to its final name.

A failure at any step leaves the previous checkpoint untouched and removes the
temporary file (tested by simulating a failed write, a failed rename and a failed
verification). When resuming, an unreadable newest checkpoint is skipped with a
warning and the next older one is used. Checkpoints load with pickle disabled.
Training stops with an error if a loss becomes NaN or infinite, without overwriting
any checkpoint.

## Reproducibility

The random batch for step N comes from a generator seeded with `[seed, 1, N]`, so it
depends only on the seed and the step number. The same seed and data give identical
weights and losses, and a run that is stopped and resumed ends with exactly the same
weights as one that never stopped. Resuming is refused if the data, seed, validation
fraction or batch size differ from the original run (a changed learning rate only
produces a warning).

## Measured results

All numbers below were measured in this environment (CPU only).

**Logged training run** (`training_log.txt`): seed 42, 2,000 steps, batch 4,096, lr 20,
vocabulary 59, 102,508 training pairs, 11,389 validation pairs. Took 6.8 s.

| Step | Train loss | Val loss | Val perplexity |
|-----:|-----------:|---------:|---------------:|
| 0 | 4.0791 | 4.0788 | 59.07 |
| 200 | 2.1678 | 2.1666 | 8.73 |
| 1000 | 2.0808 | 2.0795 | 8.00 |
| 2000 | 2.0729 | 2.0717 | 7.94 |

For reference, uniform guessing is ln(59) = 4.0775. Loss was nearly flat by the end
(2.0735 to 2.0729 over the last 200 steps).

**Resume experiment:** 1,000 steps, then `--resume` to 2,000, versus 2,000 straight
through: final weights were bit-for-bit identical (`np.array_equal` was True).

**Corruption experiment:** after deliberately overwriting the newest checkpoint with
garbage, `--resume` logged a warning, restarted from the previous checkpoint (step 1,500)
and finished normally.

**Tests:** 120 run, 120 passed, 0 failed. Of these, 67 are new in Project 3.

**Memory:** loading and tokenizing a 5,000,000-character text raised peak memory by
about 82 MB, roughly 17 bytes per character (measured once; your numbers will vary).

## Limitations

1. **The model is still a bigram model.** It sees one character of context, so generated text is word-shaped noise (see the samples in the Project 2 README and by running `generate.py`). This project improves the tooling, not the model.
2. **Validation is weak evidence here.** The corpus is synthetic and template-built, so the held-out tail looks just like the training part, and train and validation loss are almost equal. The toolkit mechanics are real; the loss values would be higher and less alike on varied real-world text.
3. **Contiguous split.** Validation is the last part of the data. If your text changes style toward the end (for example files joined alphabetically), validation will not be representative. The toolkit does not shuffle or split by file.
4. **Memory.** The whole dataset is held in memory at about 17 bytes per character. The default 50 MB cap would need roughly 850 MB at peak, so lower `--max-bytes` on a small machine.
5. **Crash safety, not crash-proof training.** A kill, power loss or crash cannot corrupt a checkpoint, but steps since the last checkpoint are lost. Ctrl+C saves first. Only the file contents are flushed to disk; the folder entry is not.
6. **Results differ slightly from Project 2's `train.py`** for the same seed (val loss 2.0717 here against 2.0714), because batches are drawn per step instead of from one random stream. Both are valid.
7. **Single process, one learning rate.** Plain gradient descent with no scheduling or early stopping. `--resume` needs the original data and seed.
8. **Inherited tokenizer limits:** unknown characters become `<unk>`, there is no Unicode normalisation, and characters are not words.

## Scope

This is Project 3 only. There is no neural network with hidden layers, no attention
and no chat interface.
