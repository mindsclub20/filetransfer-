"""Command-line trainer for the Little Talk bigram model.

    python run_training.py --data data/corpus.txt --out-dir runs/demo --steps 2000 --seed 42
    python run_training.py --data data/corpus.txt --out-dir runs/demo --steps 4000 --seed 42 --resume

Exit codes: 0 ok, 2 bad data/settings (message printed to stderr), 130 interrupted.
"""

import argparse
import json
import os
import sys
import time

from checkpointing import CheckpointManager
from dataset import DEFAULT_MAX_BYTES, DEFAULT_MIN_CHARS, load_dataset
from logger import MetricsLogger
from trainer import ResumeError, TrainConfig, run_training


def build_parser():
    p = argparse.ArgumentParser(description="Train the bigram model with logging and safe checkpoints.")
    p.add_argument("--data", default="data/corpus.txt", help="a UTF-8 text file, or a folder of .txt files")
    p.add_argument("--out-dir", default="runs/run1", help="where checkpoints and logs go")
    p.add_argument("--steps", type=int, default=2000, help="total steps to reach")
    p.add_argument("--batch-size", type=int, default=4096)
    p.add_argument("--lr", type=float, default=20.0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--val-fraction", type=float, default=0.1)
    p.add_argument("--eval-every", type=int, default=200)
    p.add_argument("--checkpoint-every", type=int, default=500)
    p.add_argument("--keep-last", type=int, default=3)
    p.add_argument("--min-chars", type=int, default=DEFAULT_MIN_CHARS)
    p.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES)
    p.add_argument("--resume", action="store_true", help="continue from the newest valid checkpoint in --out-dir")
    return p


def main(argv=None, echo=True):
    args = build_parser().parse_args(argv)
    config = TrainConfig(steps=args.steps, batch_size=args.batch_size, lr=args.lr, seed=args.seed,
                         val_fraction=args.val_fraction, eval_every=args.eval_every,
                         checkpoint_every=args.checkpoint_every, keep_last=args.keep_last)
    logger = None
    try:
        config.validate()
        dataset = load_dataset(args.data, args.val_fraction, args.min_chars, args.max_bytes)
        # Refuse BEFORE touching any file, so a mistake never overwrites an earlier run's logs.
        if not args.resume and CheckpointManager(os.path.join(args.out_dir, "checkpoints")).has_checkpoints():
            raise ResumeError(f"{os.path.join(args.out_dir, 'checkpoints')} already contains checkpoints. "
                              f"Use --resume, or choose an empty --out-dir.")
        os.makedirs(args.out_dir, exist_ok=True)
        logger = MetricsLogger(os.path.join(args.out_dir, "train.log"),
                               os.path.join(args.out_dir, "metrics.csv"),
                               append=args.resume, echo=echo)
        t0 = time.time()
        logger.message("Little Talk AI - Project 3: training toolkit")
        logger.message(f"data: {args.data} | {dataset.n_chars} chars | vocab {dataset.tokenizer.vocab_size} | "
                       f"train pairs {len(dataset.train_x)} | val pairs {len(dataset.val_x)}")
        logger.message(f"data sha256: {dataset.sha256[:16]}...")
        for w in dataset.warnings:
            logger.message(f"WARNING: {w}")
        logger.message(f"config: steps={config.steps} batch={config.batch_size} lr={config.lr} "
                       f"seed={config.seed} eval_every={config.eval_every} "
                       f"checkpoint_every={config.checkpoint_every}")
        with open(os.path.join(args.out_dir, "config.json"), "w", encoding="utf-8") as f:
            json.dump(vars(args), f, indent=2)
        result = run_training(dataset, config, args.out_dir, logger, resume=args.resume)
        logger.message(f"finished at step {result['final_step']} | best val loss "
                       f"{result['best_val']:.4f} | {time.time() - t0:.1f}s")
        return 0
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130
    except (ValueError, FileNotFoundError, NotADirectoryError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    finally:
        if logger:
            logger.close()


if __name__ == "__main__":
    sys.exit(main())
