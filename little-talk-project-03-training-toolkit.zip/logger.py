"""Little Talk AI - Project 3: simple text + CSV logging of training metrics."""

import math
import os
import time


class MetricsLogger:
    """Writes a readable text log and a CSV of (step, train, val) losses."""

    def __init__(self, text_path=None, csv_path=None, append=False, echo=True):
        self.echo = echo
        self._t0 = time.time()
        mode = "a" if append else "w"
        self._text = open(text_path, mode, encoding="utf-8") if text_path else None
        self._csv = None
        if csv_path:
            fresh = not (append and os.path.exists(csv_path) and os.path.getsize(csv_path) > 0)
            self._csv = open(csv_path, mode, encoding="utf-8")
            if fresh:
                self._csv.write("step,train_loss,val_loss,val_perplexity,seconds\n")
                self._csv.flush()

    def message(self, msg=""):
        if self.echo:
            print(msg)
        if self._text:
            self._text.write(msg + "\n")
            self._text.flush()

    def metrics(self, step, train_loss, val_loss):
        ppl = math.exp(val_loss) if val_loss < 700 else float("inf")
        self.message(f"step {step:7d} | train loss {train_loss:.4f} | "
                     f"val loss {val_loss:.4f} | val ppl {ppl:.2f}")
        if self._csv:
            self._csv.write(f"{step},{train_loss:.6f},{val_loss:.6f},{ppl:.4f},"
                            f"{time.time() - self._t0:.2f}\n")
            self._csv.flush()

    def close(self):
        for f in (self._text, self._csv):
            if f:
                f.close()
        self._text = self._csv = None
