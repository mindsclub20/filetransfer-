"""Unit tests for bigram_model.py and train.py.  Run: python -m unittest -v"""

import math
import os
import tempfile
import unittest

import numpy as np

from bigram_model import (BigramModel, count_bigram_loss, generate_text,
                          load_checkpoint, make_pairs, save_checkpoint, split_ids)
from tokenizer import CharTokenizer
from train import train

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "data", "corpus.txt")


def quiet(_msg=""):
    pass


class TestData(unittest.TestCase):
    def test_make_pairs(self):
        x, y = make_pairs([5, 6, 7, 8])
        self.assertEqual(x.tolist(), [5, 6, 7])
        self.assertEqual(y.tolist(), [6, 7, 8])

    def test_split_ids_is_contiguous(self):
        tr, va = split_ids(list(range(100)), 0.2)
        self.assertEqual(tr, list(range(80)))
        self.assertEqual(va, list(range(80, 100)))

    def test_split_rejects_bad_fraction(self):
        for bad in (0, 1, -0.1, 1.5):
            with self.assertRaises(ValueError):
                split_ids([1, 2, 3], bad)


class TestInitialisation(unittest.TestCase):
    def test_parameters_are_random_not_zero(self):
        m = BigramModel(30, seed=1)
        self.assertEqual(m.W.shape, (30, 30))
        self.assertGreater(np.abs(m.W).max(), 0)
        self.assertGreater(len(np.unique(m.W)), 800)       # not constant
        self.assertAlmostEqual(float(m.W.std()), 0.02, delta=0.005)

    def test_same_seed_same_weights_different_seed_different(self):
        self.assertTrue(np.array_equal(BigramModel(20, 7).W, BigramModel(20, 7).W))
        self.assertFalse(np.array_equal(BigramModel(20, 7).W, BigramModel(20, 8).W))

    def test_initial_loss_is_close_to_uniform_guessing(self):
        m = BigramModel(50, seed=0)
        rng = np.random.default_rng(0)
        x, y = rng.integers(0, 50, 5000), rng.integers(0, 50, 5000)
        self.assertAlmostEqual(m.loss(x, y), math.log(50), delta=0.05)

    def test_bad_vocab_size(self):
        with self.assertRaises(ValueError):
            BigramModel(0)


class TestLossAndGradient(unittest.TestCase):
    def test_probabilities_sum_to_one(self):
        m = BigramModel(12, seed=3)
        for i in range(12):
            self.assertAlmostEqual(float(m.next_char_probs(i).sum()), 1.0, places=9)

    def test_gradient_matches_numerical_gradient(self):
        m = BigramModel(6, seed=5, init_std=0.5)
        x = np.array([0, 1, 1, 2, 5, 3, 1])
        y = np.array([1, 2, 4, 0, 5, 3, 1])
        _, grad = m.loss_and_grad(x, y)
        eps, num = 1e-6, np.zeros_like(grad)
        for i in range(6):
            for j in range(6):
                old = m.W[i, j]
                m.W[i, j] = old + eps
                up = m.loss(x, y)
                m.W[i, j] = old - eps
                down = m.loss(x, y)
                m.W[i, j] = old
                num[i, j] = (up - down) / (2 * eps)
        self.assertLess(np.abs(grad - num).max(), 1e-7)

    def test_loss_matches_loss_and_grad(self):
        m = BigramModel(8, seed=2)
        x, y = np.array([0, 1, 2, 3]), np.array([1, 2, 3, 4])
        self.assertAlmostEqual(m.loss(x, y), m.loss_and_grad(x, y)[0], places=12)

    def test_input_validation(self):
        m = BigramModel(5)
        for x, y in (([], []), ([0, 1], [1]), ([5], [0]), ([-1], [0]), ([0], [9])):
            with self.assertRaises(ValueError):
                m.loss(x, y)


class TestTraining(unittest.TestCase):
    def test_learns_a_deterministic_pattern(self):
        tok = CharTokenizer.train("ab")
        ids = tok.encode("ab" * 200)
        x, y = make_pairs(ids)
        m = BigramModel(tok.vocab_size, seed=0)
        train(m, x, y, x, y, steps=300, batch_size=64, lr=5.0, seed=0, eval_every=100, log=quiet)
        a, b = tok.token_to_id["a"], tok.token_to_id["b"]
        self.assertGreater(m.next_char_probs(a)[b], 0.95)
        self.assertGreater(m.next_char_probs(b)[a], 0.95)
        self.assertEqual(generate_text(m, tok, "a", 6, seed=1), "ababab" + "a")

    def test_loss_falls_and_validation_is_reported(self):
        with open(CORPUS, encoding="utf-8") as f:
            text = f.read()[:20000]
        cut = int(len(text) * 0.9)
        tok = CharTokenizer.train(text[:cut])
        tr, va = split_ids(tok.encode(text), 0.1)
        (tx, ty), (vx, vy) = make_pairs(tr), make_pairs(va)
        m = BigramModel(tok.vocab_size, seed=4)
        hist = train(m, tx, ty, vx, vy, steps=150, batch_size=1024, lr=20.0,
                     seed=4, eval_every=50, log=quiet)
        self.assertEqual([h[0] for h in hist], [0, 50, 100, 150])
        self.assertAlmostEqual(hist[0][2], math.log(tok.vocab_size), delta=0.05)
        self.assertLess(hist[-1][1], hist[0][1] - 1.0)   # train loss dropped a lot
        self.assertLess(hist[-1][2], hist[0][2] - 1.0)   # val loss dropped a lot
        self.assertEqual(m.steps_trained, 150)

    def test_gradient_descent_approaches_count_based_model(self):
        rng = np.random.default_rng(0)
        probs = rng.dirichlet(np.ones(6) * 0.5, size=6)   # a made-up true bigram law
        seq, cur = [], 0
        for _ in range(20000):
            cur = int(rng.choice(6, p=probs[cur]))
            seq.append(cur)
        x, y = make_pairs(seq)
        m = BigramModel(6, seed=0)
        train(m, x, y, x, y, steps=1500, batch_size=2048, lr=10.0, seed=0, eval_every=500, log=quiet)
        ref = count_bigram_loss(x, y, x, y, 6, alpha=0.0001)
        self.assertLess(m.loss(x, y) - ref, 0.02)

    def test_training_is_reproducible(self):
        ids = CharTokenizer.train("hello world").encode("hello world " * 30)
        x, y = make_pairs(ids)

        def run(seed):
            m = BigramModel(CharTokenizer.train("hello world").vocab_size, seed=seed)
            h = train(m, x, y, x, y, steps=40, batch_size=32, lr=3.0, seed=seed,
                      eval_every=10, log=quiet)
            return m.W.copy(), h

        w1, h1 = run(11)
        w2, h2 = run(11)
        w3, _ = run(12)
        self.assertTrue(np.array_equal(w1, w2))
        self.assertEqual(h1, h2)
        self.assertFalse(np.array_equal(w1, w3))

    def test_bad_training_arguments(self):
        m = BigramModel(4)
        x = y = np.array([0, 1, 2])
        for kw in ({"steps": -1}, {"batch_size": 0}, {"lr": 0}):
            args = dict(steps=1, batch_size=1, lr=1.0)
            args.update(kw)
            with self.assertRaises(ValueError):
                train(m, x, y, x, y, log=quiet, **args)


class TestGeneration(unittest.TestCase):
    def setUp(self):
        self.tok = CharTokenizer.train("hello world, little talk")
        self.model = BigramModel(self.tok.vocab_size, seed=3)

    def test_starts_with_start_char_and_has_right_length(self):
        out = generate_text(self.model, self.tok, "h", 40, seed=1)
        self.assertEqual(len(out), 41)
        self.assertEqual(out[0], "h")

    def test_same_seed_same_text_different_seed_differs(self):
        a = generate_text(self.model, self.tok, "h", 60, seed=5)
        b = generate_text(self.model, self.tok, "h", 60, seed=5)
        c = generate_text(self.model, self.tok, "h", 60, seed=6)
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)

    def test_never_outputs_special_tokens(self):
        ids = self.model.generate_ids(4, 3000, seed=0, banned_ids=range(4))
        self.assertTrue(all(i >= 4 for i in ids))
        out = generate_text(self.model, self.tok, "h", 500, seed=2)
        self.assertNotIn("\ufffd", out)

    def test_unknown_or_invalid_start_character_is_rejected(self):
        for bad in ("Z", "\u2603", "", "hi", "<pad>", None):
            with self.assertRaises(ValueError, msg=repr(bad)):
                generate_text(self.model, self.tok, bad, 5)

    def test_bad_length_and_temperature(self):
        with self.assertRaises(ValueError):
            generate_text(self.model, self.tok, "h", -1)
        for t in (0, -1.0):
            with self.assertRaises(ValueError):
                generate_text(self.model, self.tok, "h", 5, temperature=t)
        self.assertEqual(generate_text(self.model, self.tok, "h", 0), "h")

    def test_low_temperature_is_more_peaked(self):
        m = BigramModel(5, seed=0, init_std=1.0)
        m.W[1] = [0, 0, 5, 0, 0]
        hot = m.generate_ids(1, 400, temperature=5.0, seed=0, banned_ids=[0])
        cold = m.generate_ids(1, 400, temperature=0.2, seed=0, banned_ids=[0])
        self.assertGreater(len(set(hot)), 1)
        self.assertGreater(cold.count(2) / len(cold), hot.count(2) / len(hot) - 0.001)


class TestCheckpoint(unittest.TestCase):
    def setUp(self):
        self.tok = CharTokenizer.train("hello \u00e9 world")
        self.model = BigramModel(self.tok.vocab_size, seed=9)
        x, y = make_pairs(self.tok.encode("hello world " * 20))
        train(self.model, x, y, x, y, steps=20, batch_size=16, lr=2.0, seed=9, eval_every=10, log=quiet)

    def test_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "m.npz")          # exact name, no hidden rename
            save_checkpoint(path, self.model, self.tok, extra={"note": "hi"})
            self.assertTrue(os.path.isfile(path))
            m2, tok2, meta = load_checkpoint(path)
        self.assertTrue(np.array_equal(self.model.W, m2.W))
        self.assertEqual(self.tok.id_to_token, tok2.id_to_token)
        self.assertEqual(m2.steps_trained, 20)
        self.assertEqual(meta["extra"], {"note": "hi"})
        self.assertEqual(generate_text(self.model, self.tok, "h", 50, seed=3),
                         generate_text(m2, tok2, "h", 50, seed=3))

    def test_extension_is_not_added_or_changed(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "weights.bin")
            save_checkpoint(path, self.model, self.tok)
            self.assertEqual(os.listdir(d), ["weights.bin"])
            load_checkpoint(path)

    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            load_checkpoint(os.path.join(tempfile.gettempdir(), "nope_no_such_ckpt.npz"))

    def test_rejects_corrupt_or_wrong_files(self):
        with tempfile.TemporaryDirectory() as d:
            junk = os.path.join(d, "junk.npz")
            with open(junk, "wb") as f:
                f.write(b"this is not a checkpoint")
            with self.assertRaises(ValueError):
                load_checkpoint(junk)

            nometa = os.path.join(d, "nometa.npz")
            with open(nometa, "wb") as f:
                np.savez(f, W=self.model.W)
            with self.assertRaises(ValueError):
                load_checkpoint(nometa)

    def test_rejects_shape_mismatch_and_nan(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "m.npz")
            save_checkpoint(path, self.model, self.tok)
            good = np.load(path, allow_pickle=False)
            meta = str(good["meta"])
            bad_shape = os.path.join(d, "shape.npz")
            with open(bad_shape, "wb") as f:
                np.savez(f, W=self.model.W[:-1], meta=np.array(meta))
            with self.assertRaises(ValueError):
                load_checkpoint(bad_shape)
            nan_w = self.model.W.copy()
            nan_w[0, 0] = np.nan
            bad_nan = os.path.join(d, "nan.npz")
            with open(bad_nan, "wb") as f:
                np.savez(f, W=nan_w, meta=np.array(meta))
            with self.assertRaises(ValueError):
                load_checkpoint(bad_nan)

    def test_pickled_content_is_refused(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "pickled.npz")
            with open(path, "wb") as f:
                np.savez(f, W=np.array([{"evil": 1}], dtype=object), meta=np.array("{}"))
            with self.assertRaises(ValueError):
                load_checkpoint(path)


class TestCorpusFile(unittest.TestCase):
    def test_corpus_exists_and_is_cpu_friendly(self):
        self.assertTrue(os.path.isfile(CORPUS))
        self.assertLess(os.path.getsize(CORPUS), 1_000_000)


if __name__ == "__main__":
    unittest.main()
