"""Train the bigram model on a local text file.

    python train.py --corpus data/corpus.txt --steps 2000 --seed 42

Prints (and optionally writes) train/validation loss as it goes, then saves a
checkpoint and a few generated samples.
"""

import argparse
import math
import sys
import time

import numpy as np

from bigram_model import (BigramModel, count_bigram_loss, generate_text,
                          make_pairs, save_checkpoint, split_ids)
from tokenizer import CharTokenizer


def train(model, train_x, train_y, val_x, val_y, steps, batch_size, lr,
          seed=0, eval_every=100, log=print):
    """Mini-batch gradient descent. Returns a list of (step, train_loss, val_loss)."""
    if steps < 0 or batch_size < 1 or lr <= 0:
        raise ValueError("steps must be >= 0, batch_size >= 1, lr > 0")
    rng = np.random.default_rng([int(seed), 1])  # batch-sampling stream
    history = []

    def evaluate(step):
        tl, vl = model.loss(train_x, train_y), model.loss(val_x, val_y)
        history.append((step, tl, vl))
        log(f"step {step:6d} | train loss {tl:.4f} | val loss {vl:.4f} | val ppl {math.exp(vl):.2f}")

    evaluate(0)
    for step in range(1, steps + 1):
        idx = rng.integers(0, len(train_x), size=min(batch_size, len(train_x)))
        model.sgd_step(train_x[idx], train_y[idx], lr)
        if step % eval_every == 0 or step == steps:
            evaluate(step)
    return history


def main(argv=None):
    p = argparse.ArgumentParser(description="Train a character-level bigram model.")
    p.add_argument("--corpus", default="data/corpus.txt")
    p.add_argument("--steps", type=int, default=2000)
    p.add_argument("--batch-size", type=int, default=4096)
    p.add_argument("--lr", type=float, default=20.0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--val-fraction", type=float, default=0.1)
    p.add_argument("--eval-every", type=int, default=100)
    p.add_argument("--out", default="checkpoints/bigram.npz")
    p.add_argument("--log-file", default=None, help="also write the log to this file")
    p.add_argument("--samples", type=int, default=3, help="sample texts to print at the end")
    p.add_argument("--sample-length", type=int, default=200)
    args = p.parse_args(argv)

    log_f = open(args.log_file, "w", encoding="utf-8") if args.log_file else None

    def log(msg=""):
        print(msg)
        if log_f:
            log_f.write(msg + "\n")
            log_f.flush()

    t0 = time.time()
    with open(args.corpus, "r", encoding="utf-8") as f:
        text = f.read()
    cut = int(len(text) * (1.0 - args.val_fraction))
    # The vocabulary comes from the TRAINING part only, so validation is honest:
    # a character first seen in validation counts as <unk>.
    tok = CharTokenizer.train(text[:cut])
    train_ids, val_ids = split_ids(tok.encode(text), args.val_fraction)
    train_x, train_y = make_pairs(train_ids)
    val_x, val_y = make_pairs(val_ids)
    n_unk_val = sum(1 for i in val_ids if i == tok.unk_id)

    model = BigramModel(tok.vocab_size, seed=args.seed)
    log("Little Talk AI - Project 2: bigram model training")
    log(f"corpus: {args.corpus} ({len(text)} chars) | vocab size: {tok.vocab_size}")
    log(f"train pairs: {len(train_x)} | val pairs: {len(val_x)} | <unk> in val: {n_unk_val}")
    log(f"parameters: {model.W.size} | seed: {args.seed} | steps: {args.steps} | "
        f"batch: {args.batch_size} | lr: {args.lr}")
    log(f"reference: uniform guessing loss = ln(V) = {math.log(tok.vocab_size):.4f}")
    log(f"reference: count-based bigram val loss    = "
        f"{count_bigram_loss(train_x, train_y, val_x, val_y, tok.vocab_size):.4f}")
    log("")

    history = train(model, train_x, train_y, val_x, val_y, args.steps,
                    args.batch_size, args.lr, args.seed, args.eval_every, log)
    save_checkpoint(args.out, model, tok, extra={
        "corpus": args.corpus, "steps": args.steps, "batch_size": args.batch_size,
        "lr": args.lr, "final_train_loss": history[-1][1], "final_val_loss": history[-1][2]})

    log("")
    log(f"saved checkpoint: {args.out}")
    log(f"training time: {time.time() - t0:.1f}s")
    log("")
    for k in range(args.samples):
        start = "T"
        if start not in tok.token_to_id:
            start = tok.id_to_token[4]
        log(f"--- sample {k + 1} (start={start!r}, seed={args.seed + k}) ---")
        log(generate_text(model, tok, start, args.sample_length, 1.0, args.seed + k))
        log("")
    if log_f:
        log_f.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
